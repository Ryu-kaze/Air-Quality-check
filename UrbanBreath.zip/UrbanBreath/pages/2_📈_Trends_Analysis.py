import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_collector import DataCollector
from visualization_utils import create_time_series_chart, create_daily_pattern_chart, create_correlation_heatmap

st.set_page_config(page_title="Trends Analysis", page_icon="📈", layout="wide")

st.title("📈 Air Quality Trends Analysis")
st.markdown("*Historical patterns and time-series analysis of air pollution data*")

# Initialize data collector
if 'data_collector' not in st.session_state:
    st.session_state.data_collector = DataCollector()

# Sidebar controls
with st.sidebar:
    st.header("Analysis Parameters")
    
    # City selection
    cities = ["Delhi", "Mumbai", "Kolkata", "Chennai", "Bangalore", "Hyderabad"]
    selected_city = st.selectbox("Select City for Analysis", cities)
    
    # Time period selection
    time_period = st.selectbox(
        "Select Time Period",
        ["Last 7 days", "Last 15 days", "Last 30 days", "Last 60 days"]
    )
    
    # Convert time period to days
    period_days = {
        "Last 7 days": 7,
        "Last 15 days": 15,
        "Last 30 days": 30,
        "Last 60 days": 60
    }
    days = period_days[time_period]
    
    # Pollutant selection
    st.subheader("Pollutants to Analyze")
    analyze_aqi = st.checkbox("AQI", value=True)
    analyze_pm25 = st.checkbox("PM2.5", value=True)
    analyze_pm10 = st.checkbox("PM10", value=True)
    analyze_no2 = st.checkbox("NO₂", value=True)
    analyze_so2 = st.checkbox("SO₂", value=False)
    analyze_o3 = st.checkbox("O₃", value=False)
    
    # Analysis options
    st.subheader("Analysis Options")
    show_moving_average = st.checkbox("Show Moving Average", value=True)
    moving_avg_window = st.slider("Moving Average Window (hours)", 6, 48, 24)
    
    # Load data button
    if st.button("🔄 Load Historical Data", type="primary"):
        with st.spinner(f"Loading {days} days of data for {selected_city}..."):
            st.session_state.historical_data = st.session_state.data_collector.get_historical_data(
                selected_city, days=days
            )
        st.success("Data loaded successfully!")

# Main content
# Load initial data if not present
if 'historical_data' not in st.session_state:
    with st.spinner(f"Loading initial data for {selected_city}..."):
        st.session_state.historical_data = st.session_state.data_collector.get_historical_data(
            selected_city, days=days
        )

historical_data = st.session_state.historical_data

if historical_data.empty:
    st.error("No historical data available. Please check your connection and try again.")
else:
    # Data overview
    st.subheader(f"📊 Data Overview - {selected_city}")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Records", len(historical_data))
    
    with col2:
        date_range = (historical_data['timestamp'].max() - historical_data['timestamp'].min()).days
        st.metric("Date Range (days)", date_range)
    
    with col3:
        if 'aqi' in historical_data.columns:
            avg_aqi = historical_data['aqi'].mean()
            st.metric("Average AQI", f"{avg_aqi:.0f}")
    
    with col4:
        if 'pm25' in historical_data.columns:
            avg_pm25 = historical_data['pm25'].mean()
            st.metric("Average PM2.5", f"{avg_pm25:.1f} μg/m³")
    
    # Create tabs for different analyses
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🕒 Time Series", "📅 Daily Patterns", "📊 Statistics", "🔗 Correlations", "📋 Data Table"
    ])
    
    with tab1:
        st.subheader("Time Series Analysis")
        
        # Prepare data with moving averages if requested
        plot_data = historical_data.copy()
        if show_moving_average and len(plot_data) > moving_avg_window:
            for pollutant in ['aqi', 'pm25', 'pm10', 'no2', 'so2', 'o3']:
                if pollutant in plot_data.columns:
                    plot_data[f'{pollutant}_ma'] = plot_data[pollutant].rolling(
                        window=moving_avg_window, center=True
                    ).mean()
        
        # Plot selected pollutants
        pollutants_to_plot = []
        if analyze_aqi and 'aqi' in plot_data.columns:
            pollutants_to_plot.append('aqi')
        if analyze_pm25 and 'pm25' in plot_data.columns:
            pollutants_to_plot.append('pm25')
        if analyze_pm10 and 'pm10' in plot_data.columns:
            pollutants_to_plot.append('pm10')
        if analyze_no2 and 'no2' in plot_data.columns:
            pollutants_to_plot.append('no2')
        if analyze_so2 and 'so2' in plot_data.columns:
            pollutants_to_plot.append('so2')
        if analyze_o3 and 'o3' in plot_data.columns:
            pollutants_to_plot.append('o3')
        
        if pollutants_to_plot:
            # Create subplot for each pollutant
            for pollutant in pollutants_to_plot:
                st.markdown(f"#### {pollutant.upper()} Trend")
                
                fig = go.Figure()
                
                # Original data
                fig.add_trace(go.Scatter(
                    x=plot_data['timestamp'],
                    y=plot_data[pollutant],
                    mode='lines',
                    name=f'{pollutant.upper()}',
                    line=dict(color='lightblue', width=1),
                    opacity=0.7
                ))
                
                # Moving average if enabled
                if show_moving_average and f'{pollutant}_ma' in plot_data.columns:
                    fig.add_trace(go.Scatter(
                        x=plot_data['timestamp'],
                        y=plot_data[f'{pollutant}_ma'],
                        mode='lines',
                        name=f'{pollutant.upper()} MA({moving_avg_window}h)',
                        line=dict(color='red', width=3)
                    ))
                
                # Add AQI category backgrounds for AQI plots
                if pollutant == 'aqi':
                    fig.add_hrect(y0=0, y1=50, fillcolor="green", opacity=0.1, line_width=0)
                    fig.add_hrect(y0=50, y1=100, fillcolor="yellow", opacity=0.1, line_width=0)
                    fig.add_hrect(y0=100, y1=150, fillcolor="orange", opacity=0.1, line_width=0)
                    fig.add_hrect(y0=150, y1=200, fillcolor="red", opacity=0.1, line_width=0)
                    fig.add_hrect(y0=200, y1=300, fillcolor="purple", opacity=0.1, line_width=0)
                
                fig.update_layout(
                    xaxis_title="Time",
                    yaxis_title=f"{pollutant.upper()} Concentration" + (" (μg/m³)" if pollutant != 'aqi' else ""),
                    hovermode='x unified',
                    height=400
                )
                
                st.plotly_chart(fig, use_container_width=True)
        
        else:
            st.warning("Please select at least one pollutant to analyze.")
    
    with tab2:
        st.subheader("Daily and Weekly Patterns")
        
        # Daily pattern analysis
        if pollutants_to_plot:
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### Hourly Pattern")
                selected_pollutant = st.selectbox(
                    "Select pollutant for daily pattern",
                    pollutants_to_plot,
                    key="daily_pattern"
                )
                
                daily_pattern_fig = create_daily_pattern_chart(historical_data, selected_pollutant)
                st.plotly_chart(daily_pattern_fig, use_container_width=True)
            
            with col2:
                st.markdown("#### Weekly Pattern")
                
                # Calculate weekly pattern
                plot_data_weekly = historical_data.copy()
                plot_data_weekly['day_of_week'] = pd.to_datetime(plot_data_weekly['timestamp']).dt.day_name()
                plot_data_weekly['weekday'] = pd.to_datetime(plot_data_weekly['timestamp']).dt.dayofweek
                
                weekly_avg = plot_data_weekly.groupby(['weekday', 'day_of_week'])[selected_pollutant].mean().reset_index()
                weekly_avg = weekly_avg.sort_values('weekday')
                
                fig_weekly = go.Figure()
                fig_weekly.add_trace(go.Bar(
                    x=weekly_avg['day_of_week'],
                    y=weekly_avg[selected_pollutant],
                    marker_color='lightcoral',
                    text=weekly_avg[selected_pollutant].round(1),
                    textposition='auto'
                ))
                
                fig_weekly.update_layout(
                    title=f'Weekly Pattern - Average {selected_pollutant.upper()}',
                    xaxis_title='Day of Week',
                    yaxis_title=f'{selected_pollutant.upper()} Concentration',
                    height=400
                )
                
                st.plotly_chart(fig_weekly, use_container_width=True)
        
        # Seasonal analysis (if data spans multiple months)
        if len(historical_data) > 720:  # More than 30 days of hourly data
            st.markdown("#### Seasonal Trend")
            
            seasonal_data = historical_data.copy()
            seasonal_data['date'] = pd.to_datetime(seasonal_data['timestamp']).dt.date
            daily_avg = seasonal_data.groupby('date')[selected_pollutant].mean().reset_index()
            
            fig_seasonal = go.Figure()
            fig_seasonal.add_trace(go.Scatter(
                x=daily_avg['date'],
                y=daily_avg[selected_pollutant],
                mode='lines+markers',
                name=f'Daily Average {selected_pollutant.upper()}',
                line=dict(color='green', width=2)
            ))
            
            fig_seasonal.update_layout(
                title=f'Seasonal Trend - Daily Average {selected_pollutant.upper()}',
                xaxis_title='Date',
                yaxis_title=f'{selected_pollutant.upper()} Concentration',
                height=400
            )
            
            st.plotly_chart(fig_seasonal, use_container_width=True)
    
    with tab3:
        st.subheader("Statistical Analysis")
        
        # Statistical summary
        st.markdown("#### Descriptive Statistics")
        
        stats_data = []
        for pollutant in ['aqi', 'pm25', 'pm10', 'no2', 'so2', 'o3']:
            if pollutant in historical_data.columns:
                series = historical_data[pollutant].dropna()
                if not series.empty:
                    stats_data.append({
                        'Pollutant': pollutant.upper(),
                        'Mean': f"{series.mean():.2f}",
                        'Median': f"{series.median():.2f}",
                        'Min': f"{series.min():.2f}",
                        'Max': f"{series.max():.2f}",
                        'Std Dev': f"{series.std():.2f}",
                        'P95': f"{series.quantile(0.95):.2f}"  # 95th percentile
                    })
        
        if stats_data:
            df_stats = pd.DataFrame(stats_data)
            st.dataframe(df_stats, use_container_width=True)
        
        # Distribution plots
        st.markdown("#### Distribution Analysis")
        
        if pollutants_to_plot:
            selected_dist_pollutant = st.selectbox(
                "Select pollutant for distribution analysis",
                pollutants_to_plot,
                key="distribution"
            )
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Histogram
                fig_hist = px.histogram(
                    historical_data,
                    x=selected_dist_pollutant,
                    nbins=30,
                    title=f'{selected_dist_pollutant.upper()} Distribution',
                    labels={selected_dist_pollutant: f'{selected_dist_pollutant.upper()} Concentration'}
                )
                st.plotly_chart(fig_hist, use_container_width=True)
            
            with col2:
                # Box plot
                fig_box = go.Figure()
                fig_box.add_trace(go.Box(
                    y=historical_data[selected_dist_pollutant],
                    name=selected_dist_pollutant.upper(),
                    boxpoints='outliers'
                ))
                fig_box.update_layout(
                    title=f'{selected_dist_pollutant.upper()} Box Plot',
                    yaxis_title=f'{selected_dist_pollutant.upper()} Concentration',
                    height=400
                )
                st.plotly_chart(fig_box, use_container_width=True)
        
        # Exceedance analysis
        st.markdown("#### Threshold Exceedance Analysis")
        
        # WHO guidelines
        who_guidelines = {
            'pm25': 15,  # μg/m³ (24-hour mean)
            'pm10': 45,  # μg/m³ (24-hour mean)
            'no2': 25,   # μg/m³ (24-hour mean)
            'aqi': 100   # Moderate threshold
        }
        
        exceedance_data = []
        for pollutant, threshold in who_guidelines.items():
            if pollutant in historical_data.columns:
                total_records = len(historical_data[pollutant].dropna())
                exceeded_records = len(historical_data[historical_data[pollutant] > threshold])
                exceedance_percentage = (exceeded_records / total_records * 100) if total_records > 0 else 0
                
                exceedance_data.append({
                    'Pollutant': pollutant.upper(),
                    'Threshold': threshold,
                    'Exceedances': exceeded_records,
                    'Total Records': total_records,
                    'Exceedance %': f"{exceedance_percentage:.1f}%"
                })
        
        if exceedance_data:
            df_exceedance = pd.DataFrame(exceedance_data)
            st.dataframe(df_exceedance, use_container_width=True)
    
    with tab4:
        st.subheader("Correlation Analysis")
        
        # Correlation heatmap
        correlation_fig = create_correlation_heatmap(historical_data)
        st.plotly_chart(correlation_fig, use_container_width=True)
        
        # Scatter plots for selected pollutant pairs
        st.markdown("#### Pollutant Relationships")
        
        available_pollutants = [col for col in ['aqi', 'pm25', 'pm10', 'no2', 'so2', 'o3'] 
                               if col in historical_data.columns]
        
        if len(available_pollutants) >= 2:
            col1, col2 = st.columns(2)
            
            with col1:
                pollutant_x = st.selectbox("X-axis pollutant", available_pollutants, key="corr_x")
            
            with col2:
                pollutant_y = st.selectbox("Y-axis pollutant", 
                                         [p for p in available_pollutants if p != pollutant_x], 
                                         key="corr_y")
            
            # Create scatter plot
            fig_scatter = px.scatter(
                historical_data,
                x=pollutant_x,
                y=pollutant_y,
                title=f'{pollutant_x.upper()} vs {pollutant_y.upper()}',
                labels={
                    pollutant_x: f'{pollutant_x.upper()} Concentration',
                    pollutant_y: f'{pollutant_y.upper()} Concentration'
                },
                opacity=0.6
            )
            
            # Add trend line
            fig_scatter.add_trace(
                px.scatter(
                    historical_data,
                    x=pollutant_x,
                    y=pollutant_y,
                    trendline="ols"
                ).data[1]
            )
            
            st.plotly_chart(fig_scatter, use_container_width=True)
            
            # Calculate correlation coefficient
            if not historical_data[pollutant_x].isna().all() and not historical_data[pollutant_y].isna().all():
                correlation = historical_data[pollutant_x].corr(historical_data[pollutant_y])
                st.metric("Correlation Coefficient", f"{correlation:.3f}")
    
    with tab5:
        st.subheader("Raw Data Table")
        
        # Data filtering options
        col1, col2 = st.columns(2)
        
        with col1:
            show_all_columns = st.checkbox("Show all columns", value=False)
        
        with col2:
            max_rows = st.selectbox("Rows to display", [100, 500, 1000, "All"], index=0)
        
        # Prepare display data
        display_data = historical_data.copy()
        
        if not show_all_columns:
            # Show only essential columns
            essential_columns = ['timestamp', 'city', 'aqi', 'pm25', 'pm10', 'no2']
            display_columns = [col for col in essential_columns if col in display_data.columns]
            display_data = display_data[display_columns]
        
        # Apply row limit
        if max_rows != "All":
            display_data = display_data.head(int(max_rows))
        
        # Format timestamp for better display
        if 'timestamp' in display_data.columns:
            display_data['timestamp'] = display_data['timestamp'].dt.strftime('%Y-%m-%d %H:%M:%S')
        
        st.dataframe(display_data, use_container_width=True)
        
        # Download options
        st.markdown("#### Download Data")
        
        col1, col2 = st.columns(2)
        
        with col1:
            csv_data = historical_data.to_csv(index=False)
            st.download_button(
                label="📥 Download as CSV",
                data=csv_data,
                file_name=f"{selected_city}_air_quality_{datetime.now().strftime('%Y%m%d')}.csv",
                mime="text/csv"
            )
        
        with col2:
            json_data = historical_data.to_json(orient='records', date_format='iso')
            st.download_button(
                label="📥 Download as JSON",
                data=json_data,
                file_name=f"{selected_city}_air_quality_{datetime.now().strftime('%Y%m%d')}.json",
                mime="application/json"
            )

# Footer
st.markdown("---")
st.info(f"📊 Analysis completed for **{selected_city}** over **{time_period.lower()}** | "
        f"🔄 Data points: {len(historical_data)} | "
        f"⚡ Powered by IBM LinuxONE")
