import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from datetime import datetime, timedelta
import sys
import os

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_collector import DataCollector
from visualization_utils import create_aqi_gauge, get_aqi_color, get_health_message, create_pollutant_comparison_chart
from health_risk_analysis import HealthRiskAnalyzer

st.set_page_config(page_title="Real-Time Dashboard", page_icon="🌍", layout="wide")

st.title("🌍 Real-Time Air Quality Dashboard")
st.markdown("*Live monitoring of air quality across major Indian cities*")

# Initialize components
if 'data_collector' not in st.session_state:
    st.session_state.data_collector = DataCollector()

if 'health_analyzer' not in st.session_state:
    st.session_state.health_analyzer = HealthRiskAnalyzer()

# Sidebar controls
with st.sidebar:
    st.header("Dashboard Controls")
    
    # City selection
    cities = ["Delhi", "Mumbai", "Kolkata", "Chennai", "Bangalore", "Hyderabad"]
    selected_cities = st.multiselect(
        "Select Cities to Monitor",
        cities,
        default=["Delhi", "Mumbai", "Bangalore"]
    )
    
    # Auto-refresh option
    auto_refresh = st.checkbox("Auto-refresh every 5 minutes", value=False)
    
    # Manual refresh
    if st.button("🔄 Refresh Data Now"):
        st.session_state.last_refresh = datetime.now()
        st.rerun()
    
    # Display last refresh time
    if 'last_refresh' in st.session_state:
        st.caption(f"Last updated: {st.session_state.last_refresh.strftime('%H:%M:%S')}")

# Auto-refresh mechanism
if auto_refresh:
    if 'last_auto_refresh' not in st.session_state:
        st.session_state.last_auto_refresh = datetime.now()
    
    time_since_refresh = datetime.now() - st.session_state.last_auto_refresh
    if time_since_refresh > timedelta(minutes=5):
        st.session_state.last_auto_refresh = datetime.now()
        st.rerun()

# Main dashboard content
if not selected_cities:
    st.warning("Please select at least one city to monitor.")
else:
    # Create tabs for different views
    tab1, tab2, tab3 = st.tabs(["📊 Overview", "🏥 Health Impact", "📈 Live Charts"])
    
    with tab1:
        st.subheader("Current Air Quality Status")
        
        # Create columns for city cards
        cols = st.columns(min(len(selected_cities), 3))
        
        city_data = {}
        for i, city in enumerate(selected_cities):
            col_index = i % 3
            
            with cols[col_index]:
                with st.container():
                    try:
                        # Get current data for the city
                        current_data = st.session_state.data_collector.get_current_aqi(city)
                        
                        if not current_data.empty:
                            aqi = current_data['aqi'].iloc[0]
                            pm25 = current_data['pm25'].iloc[0] if 'pm25' in current_data.columns else 0
                            pm10 = current_data['pm10'].iloc[0] if 'pm10' in current_data.columns else 0
                            
                            city_data[city] = current_data
                            
                            # City header
                            st.markdown(f"### 🏙️ {city}")
                            
                            # AQI display with color
                            aqi_color = get_aqi_color(aqi)
                            st.markdown(f"""
                            <div style="text-align: center; padding: 10px; border-radius: 10px; background-color: {aqi_color}; color: white; margin: 10px 0;">
                                <h2>AQI: {aqi:.0f}</h2>
                            </div>
                            """, unsafe_allow_html=True)
                            
                            # Pollutant metrics
                            col_pm25, col_pm10 = st.columns(2)
                            with col_pm25:
                                st.metric("PM2.5", f"{pm25:.1f} μg/m³")
                            with col_pm10:
                                st.metric("PM10", f"{pm10:.1f} μg/m³")
                            
                            # Health message
                            health_msg = get_health_message(aqi)
                            if aqi > 150:
                                st.error(f"⚠️ {health_msg}")
                            elif aqi > 100:
                                st.warning(f"⚠️ {health_msg}")
                            else:
                                st.success(f"✅ {health_msg}")
                            
                            # Risk score
                            risk_score = st.session_state.health_analyzer.calculate_health_risk_score(aqi, city)
                            st.metric("Health Risk Score", f"{risk_score:.2f}", 
                                    help="0 = No risk, 1 = Maximum risk")
                        
                        else:
                            st.error(f"Unable to fetch data for {city}")
                            
                    except Exception as e:
                        st.error(f"Error loading data for {city}: {str(e)}")
        
        # Summary statistics
        if city_data:
            st.subheader("📊 Summary Statistics")
            
            # Calculate overall statistics
            all_aqi = [data['aqi'].iloc[0] for data in city_data.values() if not data.empty]
            all_pm25 = [data['pm25'].iloc[0] for data in city_data.values() if not data.empty and 'pm25' in data.columns]
            
            if all_aqi:
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("Average AQI", f"{sum(all_aqi)/len(all_aqi):.0f}")
                
                with col2:
                    st.metric("Highest AQI", f"{max(all_aqi):.0f}")
                
                with col3:
                    unhealthy_count = sum(1 for aqi in all_aqi if aqi > 100)
                    st.metric("Cities with Unhealthy Air", f"{unhealthy_count}/{len(all_aqi)}")
                
                with col4:
                    if all_pm25:
                        avg_pm25 = sum(all_pm25) / len(all_pm25)
                        st.metric("Average PM2.5", f"{avg_pm25:.1f} μg/m³")
    
    with tab2:
        st.subheader("🏥 Health Impact Analysis")
        
        if city_data:
            # Health risk comparison
            st.markdown("#### Health Risk Comparison")
            
            risk_comparison_data = []
            for city, data in city_data.items():
                if not data.empty:
                    aqi = data['aqi'].iloc[0]
                    risk_score = st.session_state.health_analyzer.calculate_health_risk_score(aqi, city)
                    at_risk_pops = st.session_state.health_analyzer.get_vulnerable_populations_at_risk(aqi, city)
                    
                    total_at_risk = sum(pop_data['at_risk_count'] for pop_data in at_risk_pops.values())
                    
                    risk_comparison_data.append({
                        'City': city,
                        'AQI': aqi,
                        'Risk Score': risk_score,
                        'People at Risk': total_at_risk
                    })
            
            if risk_comparison_data:
                df_risk = pd.DataFrame(risk_comparison_data)
                st.dataframe(df_risk, use_container_width=True)
                
                # Vulnerable populations details
                st.markdown("#### Vulnerable Populations at Risk")
                
                selected_city_health = st.selectbox(
                    "Select city for detailed health analysis",
                    list(city_data.keys())
                )
                
                if selected_city_health:
                    current_aqi = city_data[selected_city_health]['aqi'].iloc[0]
                    health_chart = st.session_state.health_analyzer.create_health_inequity_chart(
                        selected_city_health, current_aqi
                    )
                    st.plotly_chart(health_chart, use_container_width=True)
                    
                    # Health recommendations
                    st.markdown("#### 💡 Health Recommendations")
                    recommendations = st.session_state.health_analyzer.generate_health_recommendations(
                        current_aqi, selected_city_health
                    )
                    
                    for recommendation in recommendations:
                        st.markdown(f"- {recommendation}")
        else:
            st.info("Select cities to view health impact analysis.")
    
    with tab3:
        st.subheader("📈 Live Data Visualization")
        
        if city_data:
            # AQI Gauges
            st.markdown("#### AQI Gauges")
            
            gauge_cols = st.columns(min(len(city_data), 3))
            for i, (city, data) in enumerate(city_data.items()):
                col_index = i % 3
                with gauge_cols[col_index]:
                    if not data.empty:
                        aqi = data['aqi'].iloc[0]
                        fig_gauge = create_aqi_gauge(aqi)
                        fig_gauge.update_layout(title=f"{city} AQI", height=250)
                        st.plotly_chart(fig_gauge, use_container_width=True)
            
            # Pollutant comparison
            st.markdown("#### Pollutant Levels Comparison")
            
            # Combine data from all selected cities
            combined_data = []
            for city, data in city_data.items():
                if not data.empty:
                    data_copy = data.copy()
                    data_copy['city'] = city
                    combined_data.append(data_copy)
            
            if combined_data:
                df_combined = pd.concat(combined_data, ignore_index=True)
                
                # Create comparison chart
                pollutants = ['pm25', 'pm10', 'no2', 'so2', 'o3']
                available_pollutants = [p for p in pollutants if p in df_combined.columns]
                
                if available_pollutants:
                    fig_comparison = go.Figure()
                    
                    for pollutant in available_pollutants:
                        fig_comparison.add_trace(go.Bar(
                            name=pollutant.upper(),
                            x=df_combined['city'],
                            y=df_combined[pollutant],
                            text=df_combined[pollutant].round(1),
                            textposition='auto'
                        ))
                    
                    fig_comparison.update_layout(
                        title='Current Pollutant Levels by City',
                        xaxis_title='City',
                        yaxis_title='Concentration (μg/m³)',
                        barmode='group',
                        height=400
                    )
                    
                    st.plotly_chart(fig_comparison, use_container_width=True)
            
            # Data table
            st.markdown("#### 📋 Detailed Data")
            
            if combined_data:
                # Prepare display data
                display_data = []
                for city, data in city_data.items():
                    if not data.empty:
                        row_data = {
                            'City': city,
                            'Timestamp': data['timestamp'].iloc[0].strftime('%Y-%m-%d %H:%M:%S'),
                            'AQI': f"{data['aqi'].iloc[0]:.0f}",
                            'PM2.5': f"{data['pm25'].iloc[0]:.1f}" if 'pm25' in data.columns else 'N/A',
                            'PM10': f"{data['pm10'].iloc[0]:.1f}" if 'pm10' in data.columns else 'N/A',
                            'NO₂': f"{data['no2'].iloc[0]:.1f}" if 'no2' in data.columns else 'N/A',
                            'SO₂': f"{data['so2'].iloc[0]:.1f}" if 'so2' in data.columns else 'N/A',
                            'O₃': f"{data['o3'].iloc[0]:.1f}" if 'o3' in data.columns else 'N/A'
                        }
                        display_data.append(row_data)
                
                df_display = pd.DataFrame(display_data)
                st.dataframe(df_display, use_container_width=True)
        
        else:
            st.info("Select cities to view live charts and data.")

# Footer with status information
st.markdown("---")
col1, col2, col3 = st.columns(3)

with col1:
    st.info("🔄 **Data Source**: OpenAQ API, CPCB")

with col2:
    st.info("⚡ **IBM LinuxONE**: Optimized Performance")

with col3:
    st.info(f"🕐 **Current Time**: {datetime.now().strftime('%H:%M:%S')}")

# Auto-refresh indicator
if auto_refresh:
    st.success("✅ Auto-refresh enabled - Updates every 5 minutes")
