import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import sys
import os
import numpy as np

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_collector import DataCollector
from ml_models import AirQualityPredictor
from visualization_utils import create_prediction_chart, create_feature_importance_chart
from health_risk_analysis import HealthRiskAnalyzer

st.set_page_config(page_title="AI Predictions", page_icon="🤖", layout="wide")

st.title("🤖 AI-Powered Air Quality Predictions")
st.markdown("*Machine Learning models for forecasting air quality and health risks*")

# Initialize components
if 'data_collector' not in st.session_state:
    st.session_state.data_collector = DataCollector()

if 'predictor' not in st.session_state:
    st.session_state.predictor = AirQualityPredictor()

if 'health_analyzer' not in st.session_state:
    st.session_state.health_analyzer = HealthRiskAnalyzer()

# Sidebar controls
with st.sidebar:
    st.header("Prediction Settings")
    
    # City selection
    cities = ["Delhi", "Mumbai", "Kolkata", "Chennai", "Bangalore", "Hyderabad"]
    selected_city = st.selectbox("Select City for Prediction", cities)
    
    # Model selection
    st.subheader("Model Configuration")
    model_type = st.radio(
        "Select Prediction Model",
        ["Random Forest", "ARIMA", "Both Models"]
    )
    
    # Training data period
    training_days = st.selectbox(
        "Training Data Period",
        [7, 15, 30, 60],
        index=2,  # Default to 30 days
        help="Number of days of historical data to use for model training"
    )
    
    # Prediction horizon
    if model_type in ["ARIMA", "Both Models"]:
        prediction_hours = st.slider(
            "Prediction Horizon (hours)",
            6, 48, 24,
            help="Number of hours to forecast ahead"
        )
    
    # Advanced settings
    with st.expander("Advanced Settings"):
        retrain_model = st.checkbox(
            "Force Model Retraining",
            help="Force retraining even if model exists"
        )
        
        confidence_level = st.slider(
            "Confidence Level (%)",
            80, 99, 95,
            help="Confidence level for prediction intervals"
        )

# Main content
st.header("🧠 Model Training & Predictions")

# Check if models need training
needs_training = (
    f'trained_{selected_city}' not in st.session_state or 
    retrain_model or
    st.session_state.get(f'training_days_{selected_city}', 0) != training_days
)

if needs_training or st.button("🚀 Train Models & Generate Predictions", type="primary"):
    
    # Load training data
    with st.spinner(f"Loading {training_days} days of training data for {selected_city}..."):
        training_data = st.session_state.data_collector.get_historical_data(
            selected_city, days=training_days
        )
    
    if training_data.empty:
        st.error("❌ No training data available. Please check data connectivity.")
    else:
        st.success(f"✅ Loaded {len(training_data)} records for model training")
        
        # Training progress
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        training_results = {}
        
        # Train Random Forest
        if model_type in ["Random Forest", "Both Models"]:
            try:
                status_text.text("Training Random Forest model...")
                progress_bar.progress(20)
                
                rf_metrics = st.session_state.predictor.train_random_forest(
                    training_data, target_column='aqi'
                )
                training_results['random_forest'] = {
                    'success': True,
                    'metrics': rf_metrics
                }
                
                progress_bar.progress(50)
                st.success("✅ Random Forest model trained successfully!")
                
            except Exception as e:
                training_results['random_forest'] = {
                    'success': False,
                    'error': str(e)
                }
                st.error(f"❌ Random Forest training failed: {str(e)}")
        
        # Train ARIMA
        if model_type in ["ARIMA", "Both Models"]:
            try:
                status_text.text("Training ARIMA model...")
                progress_bar.progress(70)
                
                arima_metrics = st.session_state.predictor.train_arima(
                    training_data, target_column='aqi'
                )
                training_results['arima'] = {
                    'success': True,
                    'metrics': arima_metrics
                }
                
                progress_bar.progress(90)
                st.success("✅ ARIMA model trained successfully!")
                
            except Exception as e:
                training_results['arima'] = {
                    'success': False,
                    'error': str(e)
                }
                st.error(f"❌ ARIMA training failed: {str(e)}")
        
        # Generate predictions
        predictions = {}
        
        if training_results.get('random_forest', {}).get('success'):
            try:
                status_text.text("Generating Random Forest predictions...")
                rf_prediction = st.session_state.predictor.predict_next_day_rf(training_data)
                predictions['random_forest'] = rf_prediction
            except Exception as e:
                st.error(f"Random Forest prediction failed: {str(e)}")
        
        if training_results.get('arima', {}).get('success'):
            try:
                status_text.text("Generating ARIMA predictions...")
                hours = prediction_hours if model_type in ["ARIMA", "Both Models"] else 24
                arima_prediction = st.session_state.predictor.predict_next_day_arima(steps=hours)
                predictions['arima'] = arima_prediction
            except Exception as e:
                st.error(f"ARIMA prediction failed: {str(e)}")
        
        progress_bar.progress(100)
        status_text.text("✅ All models trained and predictions generated!")
        
        # Store results in session state
        st.session_state[f'trained_{selected_city}'] = True
        st.session_state[f'training_days_{selected_city}'] = training_days
        st.session_state[f'training_results_{selected_city}'] = training_results
        st.session_state[f'predictions_{selected_city}'] = predictions
        st.session_state[f'training_data_{selected_city}'] = training_data

# Display results if available
if f'trained_{selected_city}' in st.session_state and st.session_state[f'trained_{selected_city}']:
    
    training_results = st.session_state.get(f'training_results_{selected_city}', {})
    predictions = st.session_state.get(f'predictions_{selected_city}', {})
    training_data = st.session_state.get(f'training_data_{selected_city}', pd.DataFrame())
    
    # Create tabs for different aspects
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🔮 Predictions", "📊 Model Performance", "🎯 Feature Importance", 
        "📈 Visualization", "⚕️ Health Implications"
    ])
    
    with tab1:
        st.subheader("🔮 Prediction Results")
        
        col1, col2 = st.columns(2)
        
        # Random Forest Predictions
        if 'random_forest' in predictions:
            with col1:
                st.markdown("#### 🌲 Random Forest Prediction")
                rf_pred = predictions['random_forest']
                
                # Main prediction
                pred_value = rf_pred['predicted_aqi']
                st.metric(
                    "Next Day AQI",
                    f"{pred_value:.0f}",
                    help="Predicted AQI for next day"
                )
                
                # Prediction interval
                if 'prediction_interval' in rf_pred:
                    interval = rf_pred['prediction_interval']
                    st.markdown(f"**Prediction Range:** {interval[0]:.0f} - {interval[1]:.0f}")
                
                # Health category
                from visualization_utils import get_aqi_category, get_aqi_color
                category = get_aqi_category(pred_value)
                color = get_aqi_color(pred_value)
                
                st.markdown(f"""
                <div style="padding: 10px; border-radius: 5px; background-color: {color}; color: white; text-align: center; margin: 10px 0;">
                    <strong>Predicted Category: {category}</strong>
                </div>
                """, unsafe_allow_html=True)
                
                # Model confidence
                st.info(f"🎯 Model Confidence: Based on {len(training_data)} training samples")
        
        # ARIMA Predictions
        if 'arima' in predictions:
            with col2:
                st.markdown("#### 📊 ARIMA Time Series Forecast")
                arima_pred = predictions['arima']
                
                # Next day average
                avg_pred = arima_pred['next_day_average']
                st.metric(
                    "Next Day Average AQI",
                    f"{avg_pred:.0f}",
                    help="ARIMA forecasted average AQI"
                )
                
                # Model performance
                if 'model_summary' in arima_pred:
                    summary = arima_pred['model_summary']
                    st.markdown(f"**AIC:** {summary.get('aic', 0):.2f}")
                    st.markdown(f"**BIC:** {summary.get('bic', 0):.2f}")
                
                # Health category for ARIMA
                category = get_aqi_category(avg_pred)
                color = get_aqi_color(avg_pred)
                
                st.markdown(f"""
                <div style="padding: 10px; border-radius: 5px; background-color: {color}; color: white; text-align: center; margin: 10px 0;">
                    <strong>Predicted Category: {category}</strong>
                </div>
                """, unsafe_allow_html=True)
        
        # Comparison if both models available
        if 'random_forest' in predictions and 'arima' in predictions:
            st.subheader("🤝 Model Comparison")
            
            rf_val = predictions['random_forest']['predicted_aqi']
            arima_val = predictions['arima']['next_day_average']
            diff = abs(rf_val - arima_val)
            avg_pred = (rf_val + arima_val) / 2
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Random Forest", f"{rf_val:.0f}")
            
            with col2:
                st.metric("ARIMA", f"{arima_val:.0f}")
            
            with col3:
                st.metric("Average Prediction", f"{avg_pred:.0f}")
            
            # Agreement analysis
            agreement_level = "High" if diff < 20 else "Medium" if diff < 50 else "Low"
            agreement_color = "green" if diff < 20 else "orange" if diff < 50 else "red"
            
            st.markdown(f"""
            **Model Agreement:** <span style="color: {agreement_color};">{agreement_level}</span> 
            (Difference: {diff:.0f} AQI points)
            """, unsafe_allow_html=True)
    
    with tab2:
        st.subheader("📊 Model Performance Metrics")
        
        # Performance metrics table
        performance_data = []
        
        if 'random_forest' in training_results and training_results['random_forest']['success']:
            rf_metrics = training_results['random_forest']['metrics']
            performance_data.append({
                'Model': 'Random Forest',
                'MAE': f"{rf_metrics.get('mae', 0):.2f}",
                'RMSE': f"{rf_metrics.get('rmse', 0):.2f}",
                'R²': f"{rf_metrics.get('r2', 0):.3f}",
                'Status': '✅ Success'
            })
        
        if 'arima' in training_results and training_results['arima']['success']:
            arima_metrics = training_results['arima']['metrics']
            performance_data.append({
                'Model': 'ARIMA',
                'MAE': f"{arima_metrics.get('mae', 0):.2f}",
                'RMSE': f"{arima_metrics.get('rmse', 0):.2f}",
                'AIC': f"{arima_metrics.get('aic', 0):.2f}",
                'BIC': f"{arima_metrics.get('bic', 0):.2f}",
                'Status': '✅ Success'
            })
        
        if performance_data:
            df_performance = pd.DataFrame(performance_data)
            st.dataframe(df_performance, use_container_width=True)
            
            # Performance interpretation
            st.markdown("#### 📖 Performance Interpretation")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.info("""
                **Metrics Explanation:**
                - **MAE**: Mean Absolute Error (lower is better)
                - **RMSE**: Root Mean Square Error (lower is better)  
                - **R²**: Coefficient of determination (higher is better, max 1.0)
                """)
            
            with col2:
                st.info("""
                **Quality Guidelines:**
                - **MAE < 20**: Excellent prediction accuracy
                - **MAE 20-40**: Good prediction accuracy
                - **MAE > 40**: Fair prediction accuracy
                """)
        
        # Training data quality assessment
        st.subheader("📈 Training Data Quality")
        
        if not training_data.empty:
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Training Samples", len(training_data))
            
            with col2:
                completeness = (1 - training_data['aqi'].isna().sum() / len(training_data)) * 100
                st.metric("Data Completeness", f"{completeness:.1f}%")
            
            with col3:
                aqi_range = training_data['aqi'].max() - training_data['aqi'].min()
                st.metric("AQI Range", f"{aqi_range:.0f}")
    
    with tab3:
        st.subheader("🎯 Feature Importance Analysis")
        
        if 'random_forest' in predictions and 'feature_importance' in predictions['random_forest']:
            feature_importance = predictions['random_forest']['feature_importance']
            
            # Feature importance chart
            importance_fig = create_feature_importance_chart(feature_importance)
            st.plotly_chart(importance_fig, use_container_width=True)
            
            # Top features explanation
            st.markdown("#### 🔍 Top Contributing Factors")
            
            top_5_features = dict(list(feature_importance.items())[:5])
            
            for i, (feature, importance) in enumerate(top_5_features.items(), 1):
                # Clean up feature names for display
                display_name = feature.replace('_', ' ').title()
                st.markdown(f"**{i}. {display_name}** - Importance: {importance:.3f}")
                
                # Add explanation for common features
                if 'lag' in feature:
                    st.caption(f"Historical values from previous time periods")
                elif 'rolling' in feature:
                    st.caption(f"Moving averages and trends")
                elif 'hour' in feature:
                    st.caption(f"Time-of-day patterns")
                elif 'month' in feature or 'day' in feature:
                    st.caption(f"Seasonal and temporal patterns")
        
        else:
            st.info("Feature importance analysis is only available for Random Forest model.")
    
    with tab4:
        st.subheader("📈 Prediction Visualization")
        
        if predictions and not training_data.empty:
            # Combine predictions for visualization
            combined_predictions = {}
            
            if 'random_forest' in predictions:
                combined_predictions.update(predictions['random_forest'])
            
            if 'arima' in predictions:
                combined_predictions.update(predictions['arima'])
            
            # Create prediction chart
            prediction_fig = create_prediction_chart(training_data, combined_predictions)
            st.plotly_chart(prediction_fig, use_container_width=True)
            
            # Hourly forecast visualization (ARIMA)
            if 'arima' in predictions and 'hourly_predictions' in predictions['arima']:
                st.markdown("#### ⏰ Hourly Forecast (ARIMA)")
                
                hourly_data = predictions['arima']['hourly_predictions']
                hours = [pred['hour'] for pred in hourly_data]
                values = [pred['predicted_aqi'] for pred in hourly_data]
                upper_bounds = [pred['upper_bound'] for pred in hourly_data]
                lower_bounds = [pred['lower_bound'] for pred in hourly_data]
                
                fig_hourly = go.Figure()
                
                # Main prediction line
                fig_hourly.add_trace(go.Scatter(
                    x=hours,
                    y=values,
                    mode='lines+markers',
                    name='Predicted AQI',
                    line=dict(color='red', width=3)
                ))
                
                # Confidence interval
                fig_hourly.add_trace(go.Scatter(
                    x=hours,
                    y=upper_bounds,
                    mode='lines',
                    line=dict(width=0),
                    showlegend=False
                ))
                
                fig_hourly.add_trace(go.Scatter(
                    x=hours,
                    y=lower_bounds,
                    mode='lines',
                    fill='tonexty',
                    fillcolor='rgba(255,0,0,0.1)',
                    line=dict(width=0),
                    name='Confidence Interval'
                ))
                
                fig_hourly.update_layout(
                    title='24-Hour AQI Forecast',
                    xaxis_title='Hour',
                    yaxis_title='Predicted AQI',
                    height=400
                )
                
                st.plotly_chart(fig_hourly, use_container_width=True)
        
        else:
            st.info("No prediction data available for visualization.")
    
    with tab5:
        st.subheader("⚕️ Health Impact Predictions")
        
        # Get the best available prediction
        if 'random_forest' in predictions and 'arima' in predictions:
            # Use average of both models
            rf_pred = predictions['random_forest']['predicted_aqi']
            arima_pred = predictions['arima']['next_day_average']
            predicted_aqi = (rf_pred + arima_pred) / 2
        elif 'random_forest' in predictions:
            predicted_aqi = predictions['random_forest']['predicted_aqi']
        elif 'arima' in predictions:
            predicted_aqi = predictions['arima']['next_day_average']
        else:
            predicted_aqi = None
        
        if predicted_aqi:
            # Health risk assessment
            risk_score = st.session_state.health_analyzer.calculate_health_risk_score(
                predicted_aqi, selected_city
            )
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.metric("Predicted Health Risk Score", f"{risk_score:.2f}")
                
                # Risk level categorization
                if risk_score < 0.3:
                    st.success("🟢 Low Health Risk")
                elif risk_score < 0.6:
                    st.warning("🟡 Moderate Health Risk")
                else:
                    st.error("🔴 High Health Risk")
            
            with col2:
                # Vulnerable populations at risk
                at_risk_pops = st.session_state.health_analyzer.get_vulnerable_populations_at_risk(
                    predicted_aqi, selected_city
                )
                
                if at_risk_pops:
                    total_at_risk = sum(pop_data['at_risk_count'] for pop_data in at_risk_pops.values())
                    st.metric("People at Risk", f"{total_at_risk:,}")
                else:
                    st.metric("People at Risk", "0")
            
            # Health recommendations
            st.markdown("#### 💡 Recommended Actions for Tomorrow")
            
            recommendations = st.session_state.health_analyzer.generate_health_recommendations(
                predicted_aqi, selected_city
            )
            
            for recommendation in recommendations:
                st.markdown(f"- {recommendation}")
            
            # Vulnerable population details
            if at_risk_pops:
                st.markdown("#### 👥 Vulnerable Groups at Risk")
                
                vuln_data = []
                for group, data in at_risk_pops.items():
                    group_display = group.replace('_', ' ').title()
                    vuln_data.append({
                        'Group': group_display,
                        'Total Population': f"{data['total_population']:,}",
                        'At Risk': f"{data['at_risk_count']:,}",
                        'Risk Level': f"{data['risk_level']:.1%}"
                    })
                
                df_vuln = pd.DataFrame(vuln_data)
                st.dataframe(df_vuln, use_container_width=True)
        
        else:
            st.warning("No prediction data available for health impact assessment.")

else:
    # Initial state - show overview and instructions
    st.info("👆 Configure your prediction settings in the sidebar and click 'Train Models & Generate Predictions' to get started.")
    
    # Show model capabilities
    st.subheader("🧠 Available AI Models")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        #### 🌲 Random Forest Regressor
        
        **Strengths:**
        - Excellent for non-linear patterns
        - Handles multiple features well
        - Provides feature importance
        - Robust to outliers
        
        **Best for:**
        - Complex air quality patterns
        - Multi-factor analysis
        - Feature importance insights
        """)
    
    with col2:
        st.markdown("""
        #### 📊 ARIMA Time Series
        
        **Strengths:**
        - Captures temporal trends
        - Seasonal pattern recognition
        - Confidence intervals
        - Hour-by-hour forecasting
        
        **Best for:**
        - Time-based predictions
        - Seasonal analysis
        - Short-term forecasting
        """)
    
    # Sample prediction workflow
    st.subheader("🔄 Prediction Workflow")
    
    st.markdown("""
    1. **Data Collection**: Gather historical air quality data from multiple sources
    2. **Feature Engineering**: Create time-based and lag features for better predictions
    3. **Model Training**: Train both Random Forest and ARIMA models on historical data
    4. **Prediction Generation**: Generate next-day AQI forecasts with confidence intervals
    5. **Health Assessment**: Analyze health implications for vulnerable populations
    6. **Recommendations**: Provide actionable health and policy recommendations
    """)

# Footer with model information
st.markdown("---")

col1, col2, col3 = st.columns(3)

with col1:
    st.info("🤖 **AI Models**: Random Forest + ARIMA")

with col2:
    st.info("⚡ **IBM LinuxONE**: High-Performance ML")

with col3:
    st.info("🎯 **Accuracy**: Real-time model validation")
