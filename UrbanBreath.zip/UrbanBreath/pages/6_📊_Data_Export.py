import streamlit as st
import pandas as pd
import json
import io
from datetime import datetime, timedelta
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_collector import DataCollector
from ml_models import AirQualityPredictor
from health_risk_analysis import HealthRiskAnalyzer
from visualization_utils import get_aqi_category

st.set_page_config(page_title="Data Export", page_icon="📊", layout="wide")

st.title("📊 Data Export & Analysis Results")
st.markdown("*Export air quality data, predictions, and health analysis results for further research and reporting*")

# Initialize components
if 'data_collector' not in st.session_state:
    st.session_state.data_collector = DataCollector()

if 'health_analyzer' not in st.session_state:
    st.session_state.health_analyzer = HealthRiskAnalyzer()

# Sidebar controls
with st.sidebar:
    st.header("Export Configuration")
    
    # Data type selection
    st.subheader("Data Types")
    export_raw_data = st.checkbox("Raw Air Quality Data", value=True)
    export_predictions = st.checkbox("ML Predictions", value=True)
    export_health_analysis = st.checkbox("Health Risk Analysis", value=True)
    export_summary_reports = st.checkbox("Summary Reports", value=True)
    
    # Geographic scope
    st.subheader("Geographic Scope")
    cities = ["Delhi", "Mumbai", "Kolkata", "Chennai", "Bangalore", "Hyderabad"]
    selected_cities = st.multiselect(
        "Select Cities",
        cities,
        default=["Delhi", "Mumbai", "Bangalore"]
    )
    
    # Time period
    st.subheader("Time Period")
    time_period = st.selectbox(
        "Data Period",
        ["Current Data", "Last 7 days", "Last 30 days", "Last 60 days", "Custom Range"]
    )
    
    if time_period == "Custom Range":
        start_date = st.date_input("Start Date", value=datetime.now() - timedelta(days=30))
        end_date = st.date_input("End Date", value=datetime.now())
    
    # Export formats
    st.subheader("Export Formats")
    export_formats = st.multiselect(
        "Select Formats",
        ["CSV", "JSON", "Excel", "PDF Report"],
        default=["CSV", "JSON"]
    )
    
    # Advanced options
    with st.expander("Advanced Options"):
        include_metadata = st.checkbox("Include Metadata", value=True)
        include_data_quality_metrics = st.checkbox("Include Data Quality Metrics", value=True)
        anonymize_location_data = st.checkbox("Anonymize Location Data", value=False)
        
        compression_format = st.selectbox(
            "Compression",
            ["None", "ZIP", "GZIP"],
            help="Compress exported files"
        )

# Convert time period to days
period_mapping = {
    "Current Data": 1,
    "Last 7 days": 7,
    "Last 30 days": 30,
    "Last 60 days": 60
}

if time_period == "Custom Range":
    days = (end_date - start_date).days
else:
    days = period_mapping.get(time_period, 30)

# Main content
if not selected_cities:
    st.warning("Please select at least one city to export data.")
else:
    # Create tabs for different export categories
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📋 Data Preview", "📊 Raw Data Export", "🤖 Predictions Export", 
        "🏥 Health Analysis Export", "📄 Report Generation"
    ])
    
    with tab1:
        st.subheader("📋 Data Preview")
        
        # Load and preview data
        if st.button("🔄 Load Data Preview", type="primary"):
            with st.spinner("Loading data preview..."):
                # Load data for preview
                preview_data = {}
                total_records = 0
                
                for city in selected_cities:
                    try:
                        if days == 1:
                            city_data = st.session_state.data_collector.get_current_aqi(city)
                        else:
                            city_data = st.session_state.data_collector.get_historical_data(city, days=days)
                        
                        if not city_data.empty:
                            preview_data[city] = city_data
                            total_records += len(city_data)
                    
                    except Exception as e:
                        st.error(f"Error loading data for {city}: {str(e)}")
                
                if preview_data:
                    st.success(f"✅ Loaded data for {len(preview_data)} cities ({total_records:,} total records)")
                    
                    # Store in session state for export
                    st.session_state.export_data = preview_data
                    
                    # Summary statistics
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        st.metric("Cities", len(preview_data))
                    
                    with col2:
                        st.metric("Total Records", f"{total_records:,}")
                    
                    with col3:
                        if total_records > 0:
                            all_data = pd.concat(preview_data.values(), ignore_index=True)
                            avg_aqi = all_data['aqi'].mean() if 'aqi' in all_data.columns else 0
                            st.metric("Average AQI", f"{avg_aqi:.0f}")
                    
                    with col4:
                        date_range = 0
                        if total_records > 0 and 'timestamp' in all_data.columns:
                            date_range = (all_data['timestamp'].max() - all_data['timestamp'].min()).days
                        st.metric("Date Range (days)", date_range)
                    
                    # Data quality assessment
                    st.subheader("📊 Data Quality Assessment")
                    
                    quality_metrics = []
                    for city, data in preview_data.items():
                        if not data.empty:
                            completeness = {}
                            for col in ['aqi', 'pm25', 'pm10', 'no2']:
                                if col in data.columns:
                                    completeness[col] = (1 - data[col].isna().sum() / len(data)) * 100
                            
                            avg_completeness = sum(completeness.values()) / len(completeness) if completeness else 0
                            
                            quality_metrics.append({
                                'City': city,
                                'Records': len(data),
                                'Data Completeness (%)': f"{avg_completeness:.1f}%",
                                'AQI Completeness (%)': f"{completeness.get('aqi', 0):.1f}%",
                                'PM2.5 Completeness (%)': f"{completeness.get('pm25', 0):.1f}%",
                                'PM10 Completeness (%)': f"{completeness.get('pm10', 0):.1f}%",
                                'NO2 Completeness (%)': f"{completeness.get('no2', 0):.1f}%"
                            })
                    
                    if quality_metrics:
                        df_quality = pd.DataFrame(quality_metrics)
                        st.dataframe(df_quality, use_container_width=True)
                    
                    # Sample data preview
                    st.subheader("🔍 Sample Data Preview")
                    
                    selected_city_preview = st.selectbox(
                        "Select city for detailed preview",
                        list(preview_data.keys())
                    )
                    
                    if selected_city_preview in preview_data:
                        sample_data = preview_data[selected_city_preview].head(10)
                        st.dataframe(sample_data, use_container_width=True)
                
                else:
                    st.error("❌ No data could be loaded for the selected cities and time period.")
    
    with tab2:
        st.subheader("📊 Raw Air Quality Data Export")
        
        if 'export_data' in st.session_state and export_raw_data:
            
            # Prepare combined dataset
            combined_data = []
            for city, data in st.session_state.export_data.items():
                if not data.empty:
                    data_copy = data.copy()
                    data_copy['export_city'] = city
                    data_copy['export_timestamp'] = datetime.now()
                    
                    # Add metadata if requested
                    if include_metadata:
                        data_copy['data_source'] = 'OpenAQ/CPCB'
                        data_copy['collection_method'] = 'API'
                        data_copy['data_quality_score'] = 0.85  # Example score
                    
                    # Anonymize if requested
                    if anonymize_location_data and 'latitude' in data_copy.columns:
                        data_copy['latitude'] = data_copy['latitude'].round(1)
                        data_copy['longitude'] = data_copy['longitude'].round(1)
                    
                    combined_data.append(data_copy)
            
            if combined_data:
                df_export = pd.concat(combined_data, ignore_index=True)
                
                st.success(f"✅ Prepared {len(df_export):,} records for export")
                
                # Export options
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("#### 📁 Individual City Files")
                    
                    for city in selected_cities:
                        if city in st.session_state.export_data:
                            city_data = st.session_state.export_data[city]
                            if not city_data.empty:
                                
                                # CSV export
                                if "CSV" in export_formats:
                                    csv_data = city_data.to_csv(index=False)
                                    st.download_button(
                                        label=f"📥 {city} - CSV",
                                        data=csv_data,
                                        file_name=f"{city}_air_quality_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
                                        mime="text/csv",
                                        key=f"csv_{city}"
                                    )
                                
                                # JSON export
                                if "JSON" in export_formats:
                                    json_data = city_data.to_json(orient='records', date_format='iso', indent=2)
                                    st.download_button(
                                        label=f"📥 {city} - JSON",
                                        data=json_data,
                                        file_name=f"{city}_air_quality_{datetime.now().strftime('%Y%m%d_%H%M')}.json",
                                        mime="application/json",
                                        key=f"json_{city}"
                                    )
                
                with col2:
                    st.markdown("#### 📁 Combined Dataset")
                    
                    # CSV export for combined data
                    if "CSV" in export_formats:
                        csv_combined = df_export.to_csv(index=False)
                        st.download_button(
                            label="📥 Combined Data - CSV",
                            data=csv_combined,
                            file_name=f"combined_air_quality_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
                            mime="text/csv",
                            key="csv_combined"
                        )
                    
                    # JSON export for combined data
                    if "JSON" in export_formats:
                        json_combined = df_export.to_json(orient='records', date_format='iso', indent=2)
                        st.download_button(
                            label="📥 Combined Data - JSON",
                            data=json_combined,
                            file_name=f"combined_air_quality_{datetime.now().strftime('%Y%m%d_%H%M')}.json",
                            mime="application/json",
                            key="json_combined"
                        )
                    
                    # Excel export
                    if "Excel" in export_formats:
                        # Create Excel file in memory
                        excel_buffer = io.BytesIO()
                        with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                            # Write each city to a separate sheet
                            for city in selected_cities:
                                if city in st.session_state.export_data:
                                    city_data = st.session_state.export_data[city]
                                    if not city_data.empty:
                                        # Limit sheet name length
                                        sheet_name = city[:30]
                                        city_data.to_excel(writer, sheet_name=sheet_name, index=False)
                        
                        excel_data = excel_buffer.getvalue()
                        st.download_button(
                            label="📥 Multi-Sheet Excel",
                            data=excel_data,
                            file_name=f"air_quality_data_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx",
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            key="excel_combined"
                        )
        
        else:
            st.info("Load data preview first to enable raw data export.")
    
    with tab3:
        st.subheader("🤖 ML Predictions Export")
        
        if export_predictions:
            
            # Generate predictions for export
            if st.button("🧠 Generate Predictions for Export"):
                with st.spinner("Generating ML predictions..."):
                    
                    predictions_data = []
                    predictor = AirQualityPredictor()
                    
                    for city in selected_cities:
                        try:
                            # Load training data
                            training_data = st.session_state.data_collector.get_historical_data(city, days=30)
                            
                            if not training_data.empty:
                                # Train and predict with Random Forest
                                try:
                                    rf_metrics = predictor.train_random_forest(training_data)
                                    rf_prediction = predictor.predict_next_day_rf(training_data)
                                    
                                    predictions_data.append({
                                        'city': city,
                                        'prediction_timestamp': datetime.now(),
                                        'model_type': 'Random Forest',
                                        'predicted_aqi': rf_prediction['predicted_aqi'],
                                        'prediction_interval_low': rf_prediction['prediction_interval'][0],
                                        'prediction_interval_high': rf_prediction['prediction_interval'][1],
                                        'model_mae': rf_metrics.get('mae', 0),
                                        'model_rmse': rf_metrics.get('rmse', 0),
                                        'model_r2': rf_metrics.get('r2', 0),
                                        'training_samples': len(training_data),
                                        'predicted_category': get_aqi_category(rf_prediction['predicted_aqi']),
                                        'confidence_score': max(0, rf_metrics.get('r2', 0))
                                    })
                                    
                                except Exception as e:
                                    st.warning(f"Random Forest prediction failed for {city}: {str(e)}")
                                
                                # Train and predict with ARIMA
                                try:
                                    arima_metrics = predictor.train_arima(training_data)
                                    arima_prediction = predictor.predict_next_day_arima(steps=24)
                                    
                                    predictions_data.append({
                                        'city': city,
                                        'prediction_timestamp': datetime.now(),
                                        'model_type': 'ARIMA',
                                        'predicted_aqi': arima_prediction['next_day_average'],
                                        'prediction_interval_low': 0,  # Simplified for ARIMA
                                        'prediction_interval_high': 0,
                                        'model_mae': arima_metrics.get('mae', 0),
                                        'model_rmse': arima_metrics.get('rmse', 0),
                                        'model_aic': arima_metrics.get('aic', 0),
                                        'model_bic': arima_metrics.get('bic', 0),
                                        'training_samples': len(training_data),
                                        'predicted_category': get_aqi_category(arima_prediction['next_day_average']),
                                        'confidence_score': 0.75  # Default for ARIMA
                                    })
                                    
                                except Exception as e:
                                    st.warning(f"ARIMA prediction failed for {city}: {str(e)}")
                        
                        except Exception as e:
                            st.error(f"Error generating predictions for {city}: {str(e)}")
                    
                    if predictions_data:
                        df_predictions = pd.DataFrame(predictions_data)
                        st.session_state.predictions_export = df_predictions
                        
                        st.success(f"✅ Generated {len(df_predictions)} predictions for export")
                        
                        # Display preview
                        st.dataframe(df_predictions, use_container_width=True)
            
            # Export predictions if available
            if 'predictions_export' in st.session_state:
                df_pred = st.session_state.predictions_export
                
                col1, col2 = st.columns(2)
                
                with col1:
                    if "CSV" in export_formats:
                        csv_pred = df_pred.to_csv(index=False)
                        st.download_button(
                            label="📥 Predictions - CSV",
                            data=csv_pred,
                            file_name=f"ml_predictions_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
                            mime="text/csv",
                            key="predictions_csv"
                        )
                
                with col2:
                    if "JSON" in export_formats:
                        json_pred = df_pred.to_json(orient='records', date_format='iso', indent=2)
                        st.download_button(
                            label="📥 Predictions - JSON",
                            data=json_pred,
                            file_name=f"ml_predictions_{datetime.now().strftime('%Y%m%d_%H%M')}.json",
                            mime="application/json",
                            key="predictions_json"
                        )
        
        else:
            st.info("Enable 'ML Predictions' in the sidebar to access prediction export.")
    
    with tab4:
        st.subheader("🏥 Health Risk Analysis Export")
        
        if export_health_analysis:
            
            if st.button("🏥 Generate Health Analysis for Export"):
                with st.spinner("Generating health risk analysis..."):
                    
                    health_analysis_data = []
                    
                    for city in selected_cities:
                        try:
                            # Get current air quality data
                            if 'export_data' in st.session_state and city in st.session_state.export_data:
                                city_data = st.session_state.export_data[city]
                                
                                if not city_data.empty:
                                    avg_aqi = city_data['aqi'].mean()
                                    
                                    # Calculate health metrics
                                    health_metrics = st.session_state.health_analyzer.calculate_health_impact_metrics(
                                        city_data, city
                                    )
                                    
                                    # Get vulnerable populations at risk
                                    at_risk_pops = st.session_state.health_analyzer.get_vulnerable_populations_at_risk(
                                        avg_aqi, city
                                    )
                                    
                                    # Calculate risk score
                                    risk_score = st.session_state.health_analyzer.calculate_health_risk_score(
                                        avg_aqi, city
                                    )
                                    
                                    total_at_risk = sum(pop_data['at_risk_count'] for pop_data in at_risk_pops.values())
                                    
                                    health_analysis_data.append({
                                        'city': city,
                                        'analysis_timestamp': datetime.now(),
                                        'average_aqi': avg_aqi,
                                        'aqi_category': get_aqi_category(avg_aqi),
                                        'health_risk_score': risk_score,
                                        'total_people_at_risk': total_at_risk,
                                        'excess_deaths_annual': health_metrics.get('excess_deaths_annual', 0),
                                        'excess_illness_cases': health_metrics.get('excess_respiratory_cases', 0),
                                        'economic_impact_inr': health_metrics.get('economic_impact_inr', 0),
                                        'population': health_metrics.get('population', 0),
                                        'low_income_population': health_metrics.get('low_income_population', 0),
                                        'unhealthy_days_percentage': health_metrics.get('percentage_unhealthy_days', 0),
                                        'who_pm25_exceedance': health_metrics.get('who_pm25_exceedance', 0),
                                        'who_pm10_exceedance': health_metrics.get('who_pm10_exceedance', 0)
                                    })
                                    
                                    # Add vulnerable group details
                                    for group, group_data in at_risk_pops.items():
                                        group_name = group.replace('_', ' ').title()
                                        health_analysis_data.append({
                                            'city': city,
                                            'analysis_timestamp': datetime.now(),
                                            'vulnerable_group': group_name,
                                            'group_population': group_data['total_population'],
                                            'group_at_risk_count': group_data['at_risk_count'],
                                            'group_risk_level': group_data['risk_level'],
                                            'group_percentage': group_data['percentage']
                                        })
                        
                        except Exception as e:
                            st.error(f"Error generating health analysis for {city}: {str(e)}")
                    
                    if health_analysis_data:
                        df_health = pd.DataFrame(health_analysis_data)
                        st.session_state.health_analysis_export = df_health
                        
                        st.success(f"✅ Generated health analysis data for export")
                        
                        # Display preview
                        st.dataframe(df_health.head(20), use_container_width=True)
            
            # Export health analysis if available
            if 'health_analysis_export' in st.session_state:
                df_health = st.session_state.health_analysis_export
                
                col1, col2 = st.columns(2)
                
                with col1:
                    if "CSV" in export_formats:
                        csv_health = df_health.to_csv(index=False)
                        st.download_button(
                            label="📥 Health Analysis - CSV",
                            data=csv_health,
                            file_name=f"health_risk_analysis_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
                            mime="text/csv",
                            key="health_csv"
                        )
                
                with col2:
                    if "JSON" in export_formats:
                        json_health = df_health.to_json(orient='records', date_format='iso', indent=2)
                        st.download_button(
                            label="📥 Health Analysis - JSON",
                            data=json_health,
                            file_name=f"health_risk_analysis_{datetime.now().strftime('%Y%m%d_%H%M')}.json",
                            mime="application/json",
                            key="health_json"
                        )
        
        else:
            st.info("Enable 'Health Risk Analysis' in the sidebar to access health analysis export.")
    
    with tab5:
        st.subheader("📄 Comprehensive Report Generation")
        
        if export_summary_reports:
            
            report_type = st.selectbox(
                "Select Report Type",
                [
                    "Executive Summary",
                    "Technical Analysis Report",
                    "Health Impact Assessment",
                    "Policy Recommendations Report",
                    "Custom Report"
                ]
            )
            
            if st.button("📊 Generate Comprehensive Report"):
                with st.spinner("Generating comprehensive report..."):
                    
                    # Compile comprehensive report data
                    report_data = {
                        'report_metadata': {
                            'report_type': report_type,
                            'generation_timestamp': datetime.now().isoformat(),
                            'cities_analyzed': selected_cities,
                            'analysis_period': time_period,
                            'data_points_analyzed': 0,
                            'report_version': '1.0'
                        },
                        'executive_summary': {},
                        'air_quality_data': {},
                        'predictions': {},
                        'health_analysis': {},
                        'recommendations': {}
                    }
                    
                    # Executive Summary
                    if 'export_data' in st.session_state:
                        all_data = pd.concat(st.session_state.export_data.values(), ignore_index=True)
                        
                        report_data['executive_summary'] = {
                            'total_records': len(all_data),
                            'cities_analyzed': len(selected_cities),
                            'average_aqi_all_cities': float(all_data['aqi'].mean()) if 'aqi' in all_data.columns else 0,
                            'worst_aqi_city': all_data.groupby('city')['aqi'].mean().idxmax() if 'aqi' in all_data.columns else '',
                            'best_aqi_city': all_data.groupby('city')['aqi'].mean().idxmin() if 'aqi' in all_data.columns else '',
                            'cities_with_unhealthy_air': len([city for city in selected_cities 
                                                            if city in st.session_state.export_data 
                                                            and st.session_state.export_data[city]['aqi'].mean() > 100]),
                            'analysis_period_days': days
                        }
                        
                        report_data['report_metadata']['data_points_analyzed'] = len(all_data)
                    
                    # Add predictions data if available
                    if 'predictions_export' in st.session_state:
                        pred_summary = st.session_state.predictions_export.groupby('city').agg({
                            'predicted_aqi': 'mean',
                            'confidence_score': 'mean'
                        }).to_dict('index')
                        
                        report_data['predictions'] = pred_summary
                    
                    # Add health analysis if available
                    if 'health_analysis_export' in st.session_state:
                        health_summary = st.session_state.health_analysis_export.groupby('city').agg({
                            'health_risk_score': 'mean',
                            'total_people_at_risk': 'sum',
                            'economic_impact_inr': 'sum'
                        }).fillna(0).to_dict('index')
                        
                        report_data['health_analysis'] = health_summary
                    
                    # Generate recommendations
                    report_data['recommendations'] = {
                        'immediate_actions': [
                            "Deploy additional air quality monitoring stations in high-risk areas",
                            "Implement emergency pollution control measures during high AQI days",
                            "Provide free N95 masks to vulnerable populations",
                            "Establish air quality alert systems for sensitive groups"
                        ],
                        'policy_recommendations': [
                            "Strengthen industrial emission standards and monitoring",
                            "Promote electric vehicle adoption and public transportation",
                            "Implement congestion pricing in high-pollution zones",
                            "Develop green infrastructure and urban forestry programs"
                        ],
                        'health_interventions': [
                            "Expand healthcare access in high-pollution areas",
                            "Conduct regular health screenings for vulnerable populations",
                            "Provide air purifiers for schools and healthcare facilities",
                            "Develop community health education programs"
                        ]
                    }
                    
                    st.session_state.comprehensive_report = report_data
                    
                    st.success("✅ Comprehensive report generated successfully!")
                    
                    # Display report summary
                    st.subheader("📋 Report Summary")
                    
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("Cities Analyzed", len(selected_cities))
                    
                    with col2:
                        total_records = report_data['report_metadata']['data_points_analyzed']
                        st.metric("Data Points", f"{total_records:,}")
                    
                    with col3:
                        avg_aqi = report_data['executive_summary'].get('average_aqi_all_cities', 0)
                        st.metric("Average AQI", f"{avg_aqi:.0f}")
            
            # Export comprehensive report
            if 'comprehensive_report' in st.session_state:
                report_data = st.session_state.comprehensive_report
                
                col1, col2 = st.columns(2)
                
                with col1:
                    if "JSON" in export_formats:
                        json_report = json.dumps(report_data, indent=2, default=str)
                        st.download_button(
                            label="📥 Comprehensive Report - JSON",
                            data=json_report,
                            file_name=f"comprehensive_report_{datetime.now().strftime('%Y%m%d_%H%M')}.json",
                            mime="application/json",
                            key="report_json"
                        )
                
                with col2:
                    # Generate simplified CSV report
                    if "CSV" in export_formats:
                        # Create a summary CSV
                        summary_data = []
                        
                        exec_summary = report_data.get('executive_summary', {})
                        summary_data.append({
                            'Metric': 'Total Records Analyzed',
                            'Value': exec_summary.get('total_records', 0),
                            'Category': 'Data Overview'
                        })
                        summary_data.append({
                            'Metric': 'Cities Analyzed',
                            'Value': exec_summary.get('cities_analyzed', 0),
                            'Category': 'Data Overview'
                        })
                        summary_data.append({
                            'Metric': 'Average AQI (All Cities)',
                            'Value': f"{exec_summary.get('average_aqi_all_cities', 0):.1f}",
                            'Category': 'Air Quality'
                        })
                        summary_data.append({
                            'Metric': 'Cities with Unhealthy Air',
                            'Value': exec_summary.get('cities_with_unhealthy_air', 0),
                            'Category': 'Air Quality'
                        })
                        
                        df_summary_report = pd.DataFrame(summary_data)
                        csv_summary_report = df_summary_report.to_csv(index=False)
                        
                        st.download_button(
                            label="📥 Report Summary - CSV",
                            data=csv_summary_report,
                            file_name=f"report_summary_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
                            mime="text/csv",
                            key="report_summary_csv"
                        )
        
        else:
            st.info("Enable 'Summary Reports' in the sidebar to access report generation.")

# Export status and metadata
st.markdown("---")
st.subheader("📊 Export Status & Metadata")

col1, col2, col3 = st.columns(3)

with col1:
    if 'export_data' in st.session_state:
        total_records = sum(len(data) for data in st.session_state.export_data.values())
        st.success(f"✅ **Raw Data Ready:** {total_records:,} records")
    else:
        st.info("📋 Raw data: Not loaded")

with col2:
    if 'predictions_export' in st.session_state:
        pred_count = len(st.session_state.predictions_export)
        st.success(f"✅ **Predictions Ready:** {pred_count} forecasts")
    else:
        st.info("🤖 Predictions: Not generated")

with col3:
    if 'health_analysis_export' in st.session_state:
        health_count = len(st.session_state.health_analysis_export)
        st.success(f"✅ **Health Analysis Ready:** {health_count} records")
    else:
        st.info("🏥 Health analysis: Not generated")

# Data usage guidelines
st.markdown("---")
st.subheader("📋 Data Usage Guidelines")

st.markdown("""
### Important Notes for Exported Data:

**Data Sources:**
- Air quality data sourced from OpenAQ API and Central Pollution Control Board (CPCB)
- Health risk calculations based on WHO guidelines and epidemiological studies
- Machine learning predictions use Random Forest and ARIMA algorithms

**Data Quality:**
- All data undergoes quality checks for completeness and accuracy
- Missing values are handled through interpolation or marked as null
- Outliers are identified and flagged but not removed

**Usage Recommendations:**
- Use exported data for research, policy analysis, and health impact studies
- Cite data sources appropriately in publications and reports  
- Consider data collection timestamps when analyzing trends
- Validate predictions against actual outcomes when possible

**Limitations:**
- Predictions are estimates based on historical patterns
- Health impact calculations use simplified epidemiological models
- Data availability may vary by city and time period
- Real-time data may have slight delays due to API limitations

**Contact Information:**
- For technical questions about exported data, refer to the IBM LinuxONE platform documentation
- For health-related interpretations, consult with public health professionals
- For policy applications, engage with local environmental authorities
""")

# Footer
col1, col2, col3 = st.columns(3)

with col1:
    st.info("📊 **Export**: Comprehensive Data & Analysis")

with col2:
    st.info("⚡ **Platform**: IBM LinuxONE High Performance")

with col3:
    st.info("📋 **Formats**: CSV, JSON, Excel, PDF Reports")
