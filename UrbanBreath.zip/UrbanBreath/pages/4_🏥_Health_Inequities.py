import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
from datetime import datetime, timedelta
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_collector import DataCollector
from health_risk_analysis import HealthRiskAnalyzer
from visualization_utils import get_aqi_color, get_aqi_category

st.set_page_config(page_title="Health Inequities", page_icon="🏥", layout="wide")

st.title("🏥 Health Inequities & Vulnerable Populations")
st.markdown("*Analyzing disproportionate health impacts of air pollution across different population groups*")

# Initialize components
if 'data_collector' not in st.session_state:
    st.session_state.data_collector = DataCollector()

if 'health_analyzer' not in st.session_state:
    st.session_state.health_analyzer = HealthRiskAnalyzer()

# Sidebar controls
with st.sidebar:
    st.header("Analysis Configuration")
    
    # Geographic scope
    st.subheader("Geographic Scope")
    analysis_scope = st.radio(
        "Select Analysis Scope",
        ["Single City", "Multi-City Comparison", "National Overview"]
    )
    
    if analysis_scope == "Single City":
        cities = ["Delhi", "Mumbai", "Kolkata", "Chennai", "Bangalore", "Hyderabad"]
        selected_city = st.selectbox("Select City", cities)
        selected_cities = [selected_city]
    else:
        cities = ["Delhi", "Mumbai", "Kolkata", "Chennai", "Bangalore", "Hyderabad"]
        selected_cities = st.multiselect(
            "Select Cities for Comparison",
            cities,
            default=["Delhi", "Mumbai", "Bangalore", "Chennai"]
        )
    
    # Vulnerable groups focus
    st.subheader("Vulnerable Groups Focus")
    focus_groups = st.multiselect(
        "Select Groups to Analyze",
        [
            "Children Under 5",
            "Elderly (65+)",
            "Respiratory Conditions",
            "Cardiovascular Conditions", 
            "Pregnant Women",
            "Outdoor Workers",
            "Low Income Households"
        ],
        default=["Children Under 5", "Elderly (65+)", "Low Income Households"]
    )
    
    # Analysis period
    st.subheader("Time Period")
    analysis_period = st.selectbox(
        "Analysis Period",
        ["Current Conditions", "Last 7 days", "Last 30 days", "Seasonal Analysis"]
    )
    
    # Health impact metrics
    st.subheader("Health Metrics")
    show_mortality_estimates = st.checkbox("Show Mortality Estimates", value=True)
    show_morbidity_estimates = st.checkbox("Show Illness Estimates", value=True)
    show_economic_impact = st.checkbox("Show Economic Impact", value=True)

# Load data for selected cities
@st.cache_data(ttl=300)  # Cache for 5 minutes
def load_city_data(cities, days=1):
    """Load air quality data for selected cities"""
    city_data = {}
    for city in cities:
        if days == 1:
            data = st.session_state.data_collector.get_current_aqi(city)
        else:
            data = st.session_state.data_collector.get_historical_data(city, days=days)
        city_data[city] = data
    return city_data

# Determine days based on analysis period
period_days = {
    "Current Conditions": 1,
    "Last 7 days": 7,
    "Last 30 days": 30,
    "Seasonal Analysis": 90
}
days = period_days.get(analysis_period, 1)

# Load data
with st.spinner("Loading air quality data..."):
    city_data = load_city_data(selected_cities, days=days)

# Main content
if not selected_cities:
    st.warning("Please select at least one city for analysis.")
else:
    # Create tabs for different analyses
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🎯 Overview", "👥 Vulnerable Populations", "💰 Economic Impact", 
        "🗺️ Inequity Mapping", "📊 Comparative Analysis"
    ])
    
    with tab1:
        st.subheader("🎯 Health Inequities Overview")
        
        # Summary metrics
        if analysis_scope == "Single City" and selected_cities:
            city = selected_cities[0]
            current_data = city_data.get(city, pd.DataFrame())
            
            if not current_data.empty:
                current_aqi = current_data['aqi'].mean() if 'aqi' in current_data.columns else 150
                
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("Current AQI", f"{current_aqi:.0f}")
                    category = get_aqi_category(current_aqi)
                    color = get_aqi_color(current_aqi)
                    st.markdown(f'<div style="color: {color}; font-weight: bold;">{category}</div>', 
                              unsafe_allow_html=True)
                
                with col2:
                    risk_score = st.session_state.health_analyzer.calculate_health_risk_score(
                        current_aqi, city
                    )
                    st.metric("Health Risk Score", f"{risk_score:.2f}")
                    risk_level = "High" if risk_score > 0.6 else "Moderate" if risk_score > 0.3 else "Low"
                    st.markdown(f"**Risk Level:** {risk_level}")
                
                with col3:
                    at_risk_pops = st.session_state.health_analyzer.get_vulnerable_populations_at_risk(
                        current_aqi, city
                    )
                    total_at_risk = sum(pop_data['at_risk_count'] for pop_data in at_risk_pops.values())
                    st.metric("People at Risk", f"{total_at_risk:,}")
                
                with col4:
                    demographics = st.session_state.health_analyzer.city_demographics.get(city, {})
                    total_population = demographics.get('population', 0)
                    risk_percentage = (total_at_risk / total_population * 100) if total_population > 0 else 0
                    st.metric("Population at Risk", f"{risk_percentage:.1f}%")
                
                # Health inequity indicators
                st.subheader("🚨 Health Inequity Indicators")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("#### Social Determinants")
                    
                    # Low income population impact
                    low_income_pct = demographics.get('low_income_percentage', 0)
                    st.metric("Low Income Population", f"{low_income_pct:.1f}%")
                    
                    if low_income_pct > 35:
                        st.error("🔴 High socioeconomic vulnerability")
                    elif low_income_pct > 25:
                        st.warning("🟡 Moderate socioeconomic vulnerability")
                    else:
                        st.success("🟢 Lower socioeconomic vulnerability")
                    
                    # Outdoor worker exposure
                    outdoor_workers = demographics.get('outdoor_workers', 0)
                    st.metric("Outdoor Workers", f"{outdoor_workers:.1f}%")
                    
                    if outdoor_workers > 25:
                        st.error("🔴 High occupational exposure risk")
                
                with col2:
                    st.markdown("#### Biological Vulnerability")
                    
                    # Age-based vulnerability
                    children_pct = demographics.get('children_under_5', 0)
                    elderly_pct = demographics.get('elderly_over_65', 0)
                    st.metric("Vulnerable Age Groups", f"{children_pct + elderly_pct:.1f}%")
                    
                    # Health conditions
                    respiratory_pct = demographics.get('respiratory_conditions', 0)
                    cardiac_pct = demographics.get('cardiovascular_conditions', 0)
                    st.metric("Pre-existing Conditions", f"{respiratory_pct + cardiac_pct:.1f}%")
                    
                    if (respiratory_pct + cardiac_pct) > 20:
                        st.error("🔴 High health vulnerability")
                
                # Inequity assessment
                st.subheader("⚖️ Inequity Assessment")
                
                inequity_score = (
                    (low_income_pct / 100) * 0.4 +  # Socioeconomic factor (40%)
                    (risk_score) * 0.3 +  # Health risk factor (30%)
                    ((children_pct + elderly_pct) / 100) * 0.2 +  # Age vulnerability (20%)
                    ((respiratory_pct + cardiac_pct) / 100) * 0.1  # Health conditions (10%)
                )
                
                st.metric("Inequity Index", f"{inequity_score:.2f}", 
                         help="0 = Low inequity, 1 = High inequity")
                
                if inequity_score > 0.7:
                    st.error("🚨 **CRITICAL INEQUITY LEVEL** - Immediate intervention needed")
                elif inequity_score > 0.5:
                    st.warning("⚠️ **HIGH INEQUITY LEVEL** - Targeted interventions recommended")
                elif inequity_score > 0.3:
                    st.info("ℹ️ **MODERATE INEQUITY LEVEL** - Monitor and prevent escalation")
                else:
                    st.success("✅ **LOW INEQUITY LEVEL** - Continue protective measures")
        
        # Multi-city overview
        elif len(selected_cities) > 1:
            st.subheader(f"Multi-City Inequity Comparison ({len(selected_cities)} cities)")
            
            comparison_data = []
            for city in selected_cities:
                data = city_data.get(city, pd.DataFrame())
                if not data.empty:
                    avg_aqi = data['aqi'].mean() if 'aqi' in data.columns else 150
                    risk_score = st.session_state.health_analyzer.calculate_health_risk_score(avg_aqi, city)
                    at_risk_pops = st.session_state.health_analyzer.get_vulnerable_populations_at_risk(avg_aqi, city)
                    total_at_risk = sum(pop_data['at_risk_count'] for pop_data in at_risk_pops.values())
                    
                    demographics = st.session_state.health_analyzer.city_demographics.get(city, {})
                    
                    comparison_data.append({
                        'City': city,
                        'AQI': avg_aqi,
                        'Risk Score': risk_score,
                        'People at Risk': total_at_risk,
                        'Low Income %': demographics.get('low_income_percentage', 0),
                        'Vulnerable Age %': demographics.get('children_under_5', 0) + demographics.get('elderly_over_65', 0),
                        'Health Conditions %': demographics.get('respiratory_conditions', 0) + demographics.get('cardiovascular_conditions', 0)
                    })
            
            if comparison_data:
                df_comparison = pd.DataFrame(comparison_data)
                
                # Display comparison table
                st.dataframe(df_comparison, use_container_width=True)
                
                # Highlight cities with highest inequity
                highest_risk_city = df_comparison.loc[df_comparison['Risk Score'].idxmax(), 'City']
                most_at_risk_city = df_comparison.loc[df_comparison['People at Risk'].idxmax(), 'City']
                
                col1, col2 = st.columns(2)
                with col1:
                    st.error(f"🔴 **Highest Risk:** {highest_risk_city}")
                with col2:
                    st.warning(f"⚠️ **Most People at Risk:** {most_at_risk_city}")
    
    with tab2:
        st.subheader("👥 Vulnerable Population Analysis")
        
        if analysis_scope == "Single City" and selected_cities:
            city = selected_cities[0]
            current_data = city_data.get(city, pd.DataFrame())
            
            if not current_data.empty:
                current_aqi = current_data['aqi'].mean()
                
                # Vulnerable population chart
                health_chart = st.session_state.health_analyzer.create_health_inequity_chart(
                    city, current_aqi
                )
                st.plotly_chart(health_chart, use_container_width=True)
                
                # Detailed breakdown
                st.subheader("📊 Detailed Vulnerability Breakdown")
                
                at_risk_pops = st.session_state.health_analyzer.get_vulnerable_populations_at_risk(
                    current_aqi, city
                )
                
                if at_risk_pops:
                    # Create detailed table
                    detailed_data = []
                    group_names = {
                        'children_under_5': 'Children Under 5',
                        'elderly_over_65': 'Elderly (65+)',
                        'respiratory_conditions': 'Respiratory Conditions',
                        'cardiovascular_conditions': 'Cardiovascular Conditions',
                        'pregnant_women': 'Pregnant Women',
                        'outdoor_workers': 'Outdoor Workers'
                    }
                    
                    for group, data in at_risk_pops.items():
                        detailed_data.append({
                            'Vulnerable Group': group_names.get(group, group),
                            'Total Population': f"{data['total_population']:,}",
                            'Population %': f"{data['percentage']:.1f}%",
                            'At Risk Count': f"{data['at_risk_count']:,}",
                            'Risk Level': f"{data['risk_level']:.1%}",
                            'Vulnerability Factor': f"{st.session_state.health_analyzer.vulnerability_factors.get(group, 1.0):.1f}x"
                        })
                    
                    df_detailed = pd.DataFrame(detailed_data)
                    st.dataframe(df_detailed, use_container_width=True)
                    
                    # Risk distribution visualization
                    st.subheader("🎯 Risk Distribution by Group")
                    
                    risk_levels = [data['risk_level'] for data in at_risk_pops.values()]
                    group_labels = [group_names.get(group, group) for group in at_risk_pops.keys()]
                    
                    fig_risk_dist = px.pie(
                        values=risk_levels,
                        names=group_labels,
                        title="Risk Distribution Across Vulnerable Groups"
                    )
                    st.plotly_chart(fig_risk_dist, use_container_width=True)
                
                # Intervention priorities
                st.subheader("🎯 Intervention Priorities")
                
                if at_risk_pops:
                    # Sort groups by risk level and population size
                    priority_groups = sorted(
                        at_risk_pops.items(),
                        key=lambda x: x[1]['risk_level'] * x[1]['at_risk_count'],
                        reverse=True
                    )
                    
                    st.markdown("#### Top Priority Groups for Intervention:")
                    
                    for i, (group, data) in enumerate(priority_groups[:3], 1):
                        group_name = group_names.get(group, group)
                        priority_score = data['risk_level'] * data['at_risk_count'] / 1000
                        
                        if i == 1:
                            st.error(f"🔴 **{i}. {group_name}** - {data['at_risk_count']:,} people at {data['risk_level']:.1%} risk")
                        elif i == 2:
                            st.warning(f"🟡 **{i}. {group_name}** - {data['at_risk_count']:,} people at {data['risk_level']:.1%} risk")
                        else:
                            st.info(f"🔵 **{i}. {group_name}** - {data['at_risk_count']:,} people at {data['risk_level']:.1%} risk")
        
        # Multi-city vulnerable population comparison
        elif len(selected_cities) > 1:
            st.subheader("Multi-City Vulnerable Population Comparison")
            
            # Create comparison chart
            comparison_data = []
            
            for city in selected_cities:
                data = city_data.get(city, pd.DataFrame())
                if not data.empty:
                    avg_aqi = data['aqi'].mean()
                    at_risk_pops = st.session_state.health_analyzer.get_vulnerable_populations_at_risk(avg_aqi, city)
                    
                    for group, group_data in at_risk_pops.items():
                        group_name = {
                            'children_under_5': 'Children Under 5',
                            'elderly_over_65': 'Elderly (65+)',
                            'respiratory_conditions': 'Respiratory Conditions',
                            'cardiovascular_conditions': 'Cardiovascular Conditions',
                            'pregnant_women': 'Pregnant Women',
                            'outdoor_workers': 'Outdoor Workers'
                        }.get(group, group)
                        
                        comparison_data.append({
                            'City': city,
                            'Group': group_name,
                            'At Risk Count': group_data['at_risk_count'],
                            'Risk Level': group_data['risk_level']
                        })
            
            if comparison_data:
                df_comp = pd.DataFrame(comparison_data)
                
                # Grouped bar chart
                fig_grouped = px.bar(
                    df_comp,
                    x='City',
                    y='At Risk Count',
                    color='Group',
                    title='Vulnerable Populations at Risk by City',
                    barmode='group'
                )
                st.plotly_chart(fig_grouped, use_container_width=True)
    
    with tab3:
        st.subheader("💰 Economic Impact of Health Inequities")
        
        if analysis_scope == "Single City" and selected_cities:
            city = selected_cities[0]
            data = city_data.get(city, pd.DataFrame())
            
            if not data.empty:
                # Calculate health impact metrics
                health_metrics = st.session_state.health_analyzer.calculate_health_impact_metrics(
                    data, city
                )
                
                if health_metrics:
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric(
                            "Estimated Excess Deaths (Annual)",
                            f"{health_metrics.get('excess_deaths_annual', 0):,}"
                        )
                    
                    with col2:
                        st.metric(
                            "Excess Illness Cases (Annual)",
                            f"{health_metrics.get('excess_respiratory_cases', 0):,}"
                        )
                    
                    with col3:
                        economic_impact = health_metrics.get('economic_impact_inr', 0)
                        st.metric(
                            "Economic Impact (₹ Crores)",
                            f"{economic_impact / 10000000:.1f}"
                        )
                    
                    # Economic impact breakdown
                    st.subheader("💸 Economic Impact Breakdown")
                    
                    # Calculate components
                    excess_deaths = health_metrics.get('excess_deaths_annual', 0)
                    excess_cases = health_metrics.get('excess_respiratory_cases', 0)
                    
                    cost_per_death = 3500000  # 35 lakhs INR
                    cost_per_illness = 25000   # 25,000 INR
                    
                    mortality_cost = excess_deaths * cost_per_death
                    morbidity_cost = excess_cases * cost_per_illness
                    
                    # Economic impact chart
                    impact_data = {
                        'Category': ['Mortality Cost', 'Morbidity Cost', 'Total Healthcare Cost'],
                        'Amount (₹ Crores)': [
                            mortality_cost / 10000000,
                            morbidity_cost / 10000000,
                            economic_impact / 10000000
                        ]
                    }
                    
                    fig_economic = px.bar(
                        impact_data,
                        x='Category',
                        y='Amount (₹ Crores)',
                        title='Economic Impact Components',
                        color='Category'
                    )
                    st.plotly_chart(fig_economic, use_container_width=True)
                    
                    # Cost per capita analysis
                    st.subheader("👤 Per Capita Impact")
                    
                    total_population = health_metrics.get('population', 1)
                    per_capita_cost = economic_impact / total_population
                    
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("Cost per Person (Annual)", f"₹ {per_capita_cost:,.0f}")
                    
                    with col2:
                        low_income_pop = health_metrics.get('low_income_population', 0)
                        low_income_burden = (economic_impact * 0.6) / low_income_pop if low_income_pop > 0 else 0
                        st.metric("Low Income Burden per Person", f"₹ {low_income_burden:,.0f}")
                    
                    with col3:
                        gdp_impact = (economic_impact / 3000000000000) * 100  # Assuming city GDP
                        st.metric("% of City GDP", f"{gdp_impact:.3f}%")
                    
                    # Inequity cost analysis
                    st.subheader("⚖️ Inequity Cost Analysis")
                    
                    st.markdown("""
                    **Disproportionate Impact on Vulnerable Groups:**
                    """)
                    
                    # Calculate burden distribution
                    vulnerable_groups = ['Low Income', 'Children', 'Elderly', 'Health Conditions']
                    burden_percentages = [60, 25, 20, 30]  # Overlapping percentages
                    
                    burden_data = []
                    for group, pct in zip(vulnerable_groups, burden_percentages):
                        group_burden = (economic_impact * pct / 100)
                        burden_data.append({
                            'Group': group,
                            'Economic Burden (₹ Crores)': group_burden / 10000000,
                            'Burden %': pct
                        })
                    
                    df_burden = pd.DataFrame(burden_data)
                    st.dataframe(df_burden, use_container_width=True)
        
        # Multi-city economic comparison
        elif len(selected_cities) > 1:
            st.subheader("Multi-City Economic Impact Comparison")
            
            economic_comparison = []
            
            for city in selected_cities:
                data = city_data.get(city, pd.DataFrame())
                if not data.empty:
                    health_metrics = st.session_state.health_analyzer.calculate_health_impact_metrics(
                        data, city
                    )
                    
                    if health_metrics:
                        economic_comparison.append({
                            'City': city,
                            'Economic Impact (₹ Crores)': health_metrics.get('economic_impact_inr', 0) / 10000000,
                            'Excess Deaths': health_metrics.get('excess_deaths_annual', 0),
                            'Excess Illness Cases': health_metrics.get('excess_respiratory_cases', 0),
                            'Per Capita Cost (₹)': health_metrics.get('economic_impact_inr', 0) / health_metrics.get('population', 1)
                        })
            
            if economic_comparison:
                df_economic_comp = pd.DataFrame(economic_comparison)
                st.dataframe(df_economic_comp, use_container_width=True)
                
                # Economic impact visualization
                fig_economic_comp = px.bar(
                    df_economic_comp,
                    x='City',
                    y='Economic Impact (₹ Crores)',
                    title='Economic Impact by City',
                    color='Economic Impact (₹ Crores)',
                    color_continuous_scale='Reds'
                )
                st.plotly_chart(fig_economic_comp, use_container_width=True)
    
    with tab4:
        st.subheader("🗺️ Health Inequity Geographic Mapping")
        
        if len(selected_cities) > 1:
            # Create vulnerability map data
            map_data = []
            
            for city in selected_cities:
                data = city_data.get(city, pd.DataFrame())
                if not data.empty:
                    avg_aqi = data['aqi'].mean()
                    risk_score = st.session_state.health_analyzer.calculate_health_risk_score(avg_aqi, city)
                    at_risk_pops = st.session_state.health_analyzer.get_vulnerable_populations_at_risk(avg_aqi, city)
                    total_at_risk = sum(pop_data['at_risk_count'] for pop_data in at_risk_pops.values())
                    
                    demographics = st.session_state.health_analyzer.city_demographics.get(city, {})
                    
                    # Simplified coordinates (in real implementation, would use actual coordinates)
                    coordinates = {
                        'Delhi': {'lat': 28.6139, 'lon': 77.2090},
                        'Mumbai': {'lat': 19.0760, 'lon': 72.8777},
                        'Kolkata': {'lat': 22.5726, 'lon': 88.3639},
                        'Chennai': {'lat': 13.0827, 'lon': 80.2707},
                        'Bangalore': {'lat': 12.9716, 'lon': 77.5946},
                        'Hyderabad': {'lat': 17.3850, 'lon': 78.4867}
                    }
                    
                    city_coord = coordinates.get(city, {'lat': 20.0, 'lon': 77.0})
                    
                    map_data.append({
                        'City': city,
                        'Latitude': city_coord['lat'],
                        'Longitude': city_coord['lon'],
                        'AQI': avg_aqi,
                        'Risk Score': risk_score,
                        'People at Risk': total_at_risk,
                        'Low Income %': demographics.get('low_income_percentage', 0),
                        'Population': demographics.get('population', 0),
                        'Vulnerable Age %': demographics.get('children_under_5', 0) + demographics.get('elderly_over_65', 0)
                    })
            
            if map_data:
                df_map = pd.DataFrame(map_data)
                
                # Risk score scatter map
                fig_map = px.scatter_mapbox(
                    df_map,
                    lat='Latitude',
                    lon='Longitude',
                    size='People at Risk',
                    color='Risk Score',
                    hover_name='City',
                    hover_data=['AQI', 'Low Income %', 'Vulnerable Age %'],
                    color_continuous_scale='Reds',
                    size_max=30,
                    zoom=4,
                    mapbox_style='open-street-map',
                    title='Health Risk Distribution Across Cities'
                )
                
                fig_map.update_layout(height=600)
                st.plotly_chart(fig_map, use_container_width=True)
                
                # Inequity heat map
                st.subheader("🌡️ Inequity Heat Map")
                
                # Calculate inequity index for each city
                df_map['Inequity Index'] = (
                    df_map['Risk Score'] * 0.4 +
                    df_map['Low Income %'] / 100 * 0.3 +
                    df_map['Vulnerable Age %'] / 100 * 0.3
                )
                
                fig_heatmap = px.scatter_mapbox(
                    df_map,
                    lat='Latitude',
                    lon='Longitude',
                    size='Population',
                    color='Inequity Index',
                    hover_name='City',
                    hover_data=['Risk Score', 'Low Income %'],
                    color_continuous_scale='YlOrRd',
                    size_max=40,
                    zoom=4,
                    mapbox_style='open-street-map',
                    title='Health Inequity Index by City'
                )
                
                fig_heatmap.update_layout(height=600)
                st.plotly_chart(fig_heatmap, use_container_width=True)
        else:
            st.info("Select multiple cities to view geographic inequity mapping.")
    
    with tab5:
        st.subheader("📊 Comparative Inequity Analysis")
        
        if len(selected_cities) > 1:
            # Comprehensive comparison matrix
            comparison_matrix = []
            
            for city in selected_cities:
                data = city_data.get(city, pd.DataFrame())
                if not data.empty:
                    avg_aqi = data['aqi'].mean()
                    risk_score = st.session_state.health_analyzer.calculate_health_risk_score(avg_aqi, city)
                    health_metrics = st.session_state.health_analyzer.calculate_health_impact_metrics(data, city)
                    at_risk_pops = st.session_state.health_analyzer.get_vulnerable_populations_at_risk(avg_aqi, city)
                    
                    demographics = st.session_state.health_analyzer.city_demographics.get(city, {})
                    
                    total_at_risk = sum(pop_data['at_risk_count'] for pop_data in at_risk_pops.values())
                    risk_percentage = (total_at_risk / demographics.get('population', 1) * 100)
                    
                    comparison_matrix.append({
                        'City': city,
                        'AQI': avg_aqi,
                        'Health Risk Score': risk_score,
                        'People at Risk': total_at_risk,
                        '% Population at Risk': risk_percentage,
                        'Low Income %': demographics.get('low_income_percentage', 0),
                        'Vulnerable Age %': demographics.get('children_under_5', 0) + demographics.get('elderly_over_65', 0),
                        'Health Conditions %': demographics.get('respiratory_conditions', 0) + demographics.get('cardiovascular_conditions', 0),
                        'Economic Impact (₹ Crores)': health_metrics.get('economic_impact_inr', 0) / 10000000 if health_metrics else 0,
                        'Inequity Index': (
                            risk_score * 0.4 +
                            demographics.get('low_income_percentage', 0) / 100 * 0.3 +
                            (demographics.get('children_under_5', 0) + demographics.get('elderly_over_65', 0)) / 100 * 0.3
                        )
                    })
            
            if comparison_matrix:
                df_matrix = pd.DataFrame(comparison_matrix)
                
                # Display comprehensive table
                st.dataframe(df_matrix, use_container_width=True)
                
                # Rankings
                st.subheader("🏆 City Rankings")
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.markdown("#### Highest Health Risk")
                    risk_ranking = df_matrix.nlargest(3, 'Health Risk Score')[['City', 'Health Risk Score']]
                    for idx, row in risk_ranking.iterrows():
                        if idx == risk_ranking.index[0]:
                            st.error(f"🔴 1. {row['City']} ({row['Health Risk Score']:.2f})")
                        elif idx == risk_ranking.index[1]:
                            st.warning(f"🟡 2. {row['City']} ({row['Health Risk Score']:.2f})")
                        else:
                            st.info(f"🔵 3. {row['City']} ({row['Health Risk Score']:.2f})")
                
                with col2:
                    st.markdown("#### Most People at Risk")
                    people_ranking = df_matrix.nlargest(3, 'People at Risk')[['City', 'People at Risk']]
                    for idx, row in people_ranking.iterrows():
                        rank = list(people_ranking.index).index(idx) + 1
                        st.markdown(f"{rank}. **{row['City']}** - {row['People at Risk']:,} people")
                
                with col3:
                    st.markdown("#### Highest Inequity Index")
                    inequity_ranking = df_matrix.nlargest(3, 'Inequity Index')[['City', 'Inequity Index']]
                    for idx, row in inequity_ranking.iterrows():
                        rank = list(inequity_ranking.index).index(idx) + 1
                        st.markdown(f"{rank}. **{row['City']}** - {row['Inequity Index']:.2f}")
                
                # Correlation analysis
                st.subheader("🔗 Factor Correlations")
                
                # Calculate correlations
                numeric_cols = ['AQI', 'Health Risk Score', '% Population at Risk', 'Low Income %', 
                               'Vulnerable Age %', 'Economic Impact (₹ Crores)']
                correlation_matrix = df_matrix[numeric_cols].corr()
                
                fig_corr = px.imshow(
                    correlation_matrix,
                    text_auto=True,
                    aspect='auto',
                    title='Correlation Matrix: Health Inequity Factors',
                    color_continuous_scale='RdBu_r'
                )
                st.plotly_chart(fig_corr, use_container_width=True)
                
                # Key insights
                st.subheader("💡 Key Insights")
                
                # Find strongest correlations
                highest_risk_city = df_matrix.loc[df_matrix['Health Risk Score'].idxmax(), 'City']
                lowest_risk_city = df_matrix.loc[df_matrix['Health Risk Score'].idxmin(), 'City']
                
                most_inequitable = df_matrix.loc[df_matrix['Inequity Index'].idxmax(), 'City']
                least_inequitable = df_matrix.loc[df_matrix['Inequity Index'].idxmin(), 'City']
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.error(f"🔴 **Critical Action Needed:** {highest_risk_city}")
                    st.error(f"🔴 **Most Inequitable:** {most_inequitable}")
                
                with col2:
                    st.success(f"🟢 **Best Performing:** {lowest_risk_city}")
                    st.success(f"🟢 **Most Equitable:** {least_inequitable}")
        
        else:
            st.info("Select multiple cities for comparative analysis.")

# Footer with policy recommendations
st.markdown("---")
st.subheader("📋 Policy Recommendations")

if selected_cities:
    st.markdown("""
    ### Immediate Actions Needed:
    
    1. **Targeted Health Interventions**
       - Free health screenings for vulnerable populations
       - Distribution of N95 masks in high-risk areas
       - Mobile health units in low-income neighborhoods
    
    2. **Environmental Justice Measures**
       - Prioritize pollution control in areas with high vulnerable populations
       - Green space development in underserved communities
       - Industrial emission monitoring near residential areas
    
    3. **Social Protection Programs**
       - Air quality alerts for vulnerable groups
       - Indoor air quality improvement subsidies
       - Occupational health protection for outdoor workers
    
    4. **Data and Monitoring**
       - Hyperlocal air quality monitoring
       - Health impact surveillance systems
       - Community-based health monitoring programs
    """)

col1, col2, col3 = st.columns(3)

with col1:
    st.info("🏥 **Focus**: Health Equity Analysis")

with col2:
    st.info("⚡ **Platform**: IBM LinuxONE")

with col3:
    st.info("📊 **Data**: Real-time Health Impact Assessment")
