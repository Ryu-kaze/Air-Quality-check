import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
from datetime import datetime, timedelta
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data_collector import DataCollector
from health_risk_analysis import HealthRiskAnalyzer
from visualization_utils import get_aqi_color, get_aqi_category

st.set_page_config(page_title="Geographic Analysis", page_icon="🗺️", layout="wide")

st.title("🗺️ Geographic Air Quality Analysis")
st.markdown("*Spatial patterns and geographic distribution of air pollution and health risks*")

# Initialize components
if 'data_collector' not in st.session_state:
    st.session_state.data_collector = DataCollector()

if 'health_analyzer' not in st.session_state:
    st.session_state.health_analyzer = HealthRiskAnalyzer()

# City coordinates and metadata
CITY_DATA = {
    'Delhi': {'lat': 28.6139, 'lon': 77.2090, 'region': 'North', 'population': 32900000, 'area_km2': 1484},
    'Mumbai': {'lat': 19.0760, 'lon': 72.8777, 'region': 'West', 'population': 20700000, 'area_km2': 4355},
    'Kolkata': {'lat': 22.5726, 'lon': 88.3639, 'region': 'East', 'population': 15000000, 'area_km2': 1886},
    'Chennai': {'lat': 13.0827, 'lon': 80.2707, 'region': 'South', 'population': 11700000, 'area_km2': 1189},
    'Bangalore': {'lat': 12.9716, 'lon': 77.5946, 'region': 'South', 'population': 13200000, 'area_km2': 741},
    'Hyderabad': {'lat': 17.3850, 'lon': 78.4867, 'region': 'South', 'population': 10500000, 'area_km2': 650}
}

# Sidebar controls
with st.sidebar:
    st.header("Geographic Analysis Settings")
    
    # Analysis type
    analysis_type = st.selectbox(
        "Select Analysis Type",
        [
            "City-Level Overview",
            "Regional Comparison", 
            "Hotspot Analysis",
            "Spatial Clustering",
            "Distance-Based Analysis"
        ]
    )
    
    # City selection
    st.subheader("Geographic Scope")
    if analysis_type == "City-Level Overview":
        selected_cities = st.multiselect(
            "Select Cities",
            list(CITY_DATA.keys()),
            default=["Delhi", "Mumbai", "Bangalore", "Chennai"]
        )
    else:
        selected_cities = st.multiselect(
            "Select Cities for Analysis",
            list(CITY_DATA.keys()),
            default=list(CITY_DATA.keys())
        )
    
    # Time period
    st.subheader("Time Period")
    time_period = st.selectbox(
        "Analysis Period",
        ["Current Snapshot", "Last 7 days", "Last 30 days", "Historical Trend"]
    )
    
    # Visualization options
    st.subheader("Map Visualization")
    map_style = st.selectbox(
        "Map Style",
        ["open-street-map", "carto-positron", "carto-darkmatter", "satellite-streets"]
    )
    
    show_population_overlay = st.checkbox("Show Population Density", value=True)
    show_health_risk_overlay = st.checkbox("Show Health Risk Areas", value=True)
    
    # Advanced settings
    with st.expander("Advanced Settings"):
        clustering_algorithm = st.selectbox(
            "Clustering Method",
            ["K-means", "Hierarchical", "DBSCAN"]
        )
        
        distance_threshold = st.slider(
            "Distance Analysis Threshold (km)",
            10, 200, 50,
            help="Maximum distance for spatial analysis"
        )

# Load geographic data
@st.cache_data(ttl=300)
def load_geographic_data(cities, days=1):
    """Load air quality data with geographic information"""
    geographic_data = []
    
    for city in cities:
        if days == 1:
            data = st.session_state.data_collector.get_current_aqi(city)
        else:
            data = st.session_state.data_collector.get_historical_data(city, days=days)
        
        if not data.empty:
            # Add geographic metadata
            city_info = CITY_DATA.get(city, {})
            data['city'] = city
            data['latitude'] = city_info.get('lat', 0)
            data['longitude'] = city_info.get('lon', 0)
            data['region'] = city_info.get('region', 'Unknown')
            data['population'] = city_info.get('population', 0)
            data['area_km2'] = city_info.get('area_km2', 0)
            
            # Calculate derived metrics
            if 'aqi' in data.columns:
                data['aqi_category'] = data['aqi'].apply(get_aqi_category)
                data['aqi_color'] = data['aqi'].apply(get_aqi_color)
            
            # Health risk calculation
            if 'aqi' in data.columns:
                data['health_risk_score'] = data.apply(
                    lambda row: st.session_state.health_analyzer.calculate_health_risk_score(
                        row['aqi'], city
                    ), axis=1
                )
            
            geographic_data.append(data)
    
    return pd.concat(geographic_data, ignore_index=True) if geographic_data else pd.DataFrame()

# Determine analysis period
period_days = {
    "Current Snapshot": 1,
    "Last 7 days": 7,
    "Last 30 days": 30,
    "Historical Trend": 90
}
days = period_days.get(time_period, 1)

# Load data
if selected_cities:
    with st.spinner("Loading geographic air quality data..."):
        geo_data = load_geographic_data(selected_cities, days=days)
else:
    geo_data = pd.DataFrame()

# Main content
if geo_data.empty:
    st.warning("Please select cities and ensure data is available for analysis.")
else:
    # Create tabs based on analysis type
    if analysis_type == "City-Level Overview":
        tab1, tab2, tab3, tab4 = st.tabs([
            "🗺️ Interactive Map", "📊 City Metrics", "🎯 Spatial Distribution", "📈 Trends"
        ])
        
        with tab1:
            st.subheader("🗺️ Interactive Air Quality Map")
            
            # Aggregate data by city for mapping
            city_summary = geo_data.groupby('city').agg({
                'aqi': 'mean',
                'pm25': 'mean',
                'pm10': 'mean',
                'no2': 'mean',
                'latitude': 'first',
                'longitude': 'first',
                'population': 'first',
                'health_risk_score': 'mean'
            }).reset_index()
            
            # Create main map
            fig_map = px.scatter_mapbox(
                city_summary,
                lat='latitude',
                lon='longitude',
                size='population',
                color='aqi',
                hover_name='city',
                hover_data={
                    'aqi': ':.1f',
                    'pm25': ':.1f',
                    'pm10': ':.1f',
                    'health_risk_score': ':.2f',
                    'population': ':,',
                    'latitude': False,
                    'longitude': False
                },
                color_continuous_scale='Reds',
                size_max=50,
                zoom=4.5,
                center={'lat': 20.5937, 'lon': 78.9629},  # Center of India
                mapbox_style=map_style,
                title='Air Quality Index Distribution Across Cities'
            )
            
            fig_map.update_layout(height=600, margin={"r":0,"t":50,"l":0,"b":0})
            st.plotly_chart(fig_map, use_container_width=True)
            
            # Map controls and filters
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Cities Analyzed", len(city_summary))
            
            with col2:
                avg_aqi = city_summary['aqi'].mean()
                st.metric("Average AQI", f"{avg_aqi:.1f}")
            
            with col3:
                unhealthy_cities = len(city_summary[city_summary['aqi'] > 100])
                st.metric("Cities with Unhealthy Air", f"{unhealthy_cities}/{len(city_summary)}")
            
            # Health risk overlay map
            if show_health_risk_overlay:
                st.subheader("🏥 Health Risk Geographic Distribution")
                
                fig_risk_map = px.scatter_mapbox(
                    city_summary,
                    lat='latitude',
                    lon='longitude',
                    size='population',
                    color='health_risk_score',
                    hover_name='city',
                    hover_data={
                        'health_risk_score': ':.3f',
                        'aqi': ':.1f',
                        'population': ':,',
                        'latitude': False,
                        'longitude': False
                    },
                    color_continuous_scale='YlOrRd',
                    size_max=50,
                    zoom=4.5,
                    center={'lat': 20.5937, 'lon': 78.9629},
                    mapbox_style=map_style,
                    title='Health Risk Score Distribution'
                )
                
                fig_risk_map.update_layout(height=500, margin={"r":0,"t":50,"l":0,"b":0})
                st.plotly_chart(fig_risk_map, use_container_width=True)
        
        with tab2:
            st.subheader("📊 City-Level Air Quality Metrics")
            
            # Detailed city comparison
            city_metrics = geo_data.groupby('city').agg({
                'aqi': ['mean', 'max', 'min', 'std'],
                'pm25': ['mean', 'max'],
                'pm10': ['mean', 'max'],
                'no2': ['mean', 'max'],
                'health_risk_score': 'mean',
                'population': 'first',
                'area_km2': 'first'
            }).round(2)
            
            # Flatten column names
            city_metrics.columns = ['_'.join(col).strip() for col in city_metrics.columns]
            city_metrics = city_metrics.reset_index()
            
            # Calculate additional metrics
            city_metrics['population_density'] = city_metrics['population_first'] / city_metrics['area_km2_first']
            city_metrics['pollution_per_capita'] = city_metrics['aqi_mean'] / (city_metrics['population_first'] / 1000000)
            
            st.dataframe(city_metrics, use_container_width=True)
            
            # City ranking charts
            col1, col2 = st.columns(2)
            
            with col1:
                # AQI ranking
                fig_aqi_rank = px.bar(
                    city_metrics.sort_values('aqi_mean', ascending=False),
                    x='city',
                    y='aqi_mean',
                    color='aqi_mean',
                    color_continuous_scale='Reds',
                    title='Cities Ranked by Average AQI'
                )
                fig_aqi_rank.update_layout(showlegend=False)
                st.plotly_chart(fig_aqi_rank, use_container_width=True)
            
            with col2:
                # Health risk ranking
                fig_risk_rank = px.bar(
                    city_metrics.sort_values('health_risk_score_mean', ascending=False),
                    x='city',
                    y='health_risk_score_mean',
                    color='health_risk_score_mean',
                    color_continuous_scale='OrRd',
                    title='Cities Ranked by Health Risk Score'
                )
                fig_risk_rank.update_layout(showlegend=False)
                st.plotly_chart(fig_risk_rank, use_container_width=True)
            
            # Population vs pollution analysis
            st.subheader("👥 Population vs Pollution Analysis")
            
            fig_pop_poll = px.scatter(
                city_metrics,
                x='population_first',
                y='aqi_mean',
                size='area_km2_first',
                color='health_risk_score_mean',
                hover_name='city',
                hover_data={
                    'population_density': ':.0f',
                    'pollution_per_capita': ':.2f'
                },
                title='Population Size vs Air Quality',
                labels={
                    'population_first': 'Population',
                    'aqi_mean': 'Average AQI',
                    'health_risk_score_mean': 'Health Risk Score'
                }
            )
            st.plotly_chart(fig_pop_poll, use_container_width=True)
        
        with tab3:
            st.subheader("🎯 Spatial Distribution Analysis")
            
            # Distance matrix calculation
            if len(selected_cities) > 1:
                st.markdown("#### 📏 Inter-City Distance Analysis")
                
                # Calculate distances between cities (simplified Euclidean distance)
                distance_data = []
                for i, city1 in enumerate(selected_cities):
                    for j, city2 in enumerate(selected_cities):
                        if i != j:
                            coord1 = CITY_DATA[city1]
                            coord2 = CITY_DATA[city2]
                            
                            # Rough distance calculation (not precise geographic distance)
                            lat_diff = coord1['lat'] - coord2['lat']
                            lon_diff = coord1['lon'] - coord2['lon']
                            distance = np.sqrt(lat_diff**2 + lon_diff**2) * 111  # Convert to km approximately
                            
                            # Get AQI values
                            aqi1 = geo_data[geo_data['city'] == city1]['aqi'].mean()
                            aqi2 = geo_data[geo_data['city'] == city2]['aqi'].mean()
                            aqi_diff = abs(aqi1 - aqi2)
                            
                            distance_data.append({
                                'City 1': city1,
                                'City 2': city2,
                                'Distance (km)': distance,
                                'AQI Difference': aqi_diff,
                                'AQI 1': aqi1,
                                'AQI 2': aqi2
                            })
                
                df_distance = pd.DataFrame(distance_data)
                
                # Distance vs AQI difference correlation
                fig_dist_corr = px.scatter(
                    df_distance,
                    x='Distance (km)',
                    y='AQI Difference',
                    hover_data=['City 1', 'City 2', 'AQI 1', 'AQI 2'],
                    title='Distance vs AQI Difference Between Cities',
                    trendline='ols'
                )
                st.plotly_chart(fig_dist_corr, use_container_width=True)
                
                # Distance matrix heatmap
                pivot_distance = df_distance.pivot(index='City 1', columns='City 2', values='Distance (km)')
                
                fig_heatmap = px.imshow(
                    pivot_distance,
                    text_auto=True,
                    aspect='auto',
                    title='Inter-City Distance Matrix (km)',
                    color_continuous_scale='Blues'
                )
                st.plotly_chart(fig_heatmap, use_container_width=True)
            
            # Spatial clustering analysis
            st.markdown("#### 🎯 Pollution Hotspot Identification")
            
            # Simple clustering based on AQI levels
            city_summary = geo_data.groupby('city').agg({
                'aqi': 'mean',
                'health_risk_score': 'mean',
                'latitude': 'first',
                'longitude': 'first'
            }).reset_index()
            
            # Define pollution clusters
            def assign_cluster(aqi):
                if aqi > 200:
                    return "Severe Pollution"
                elif aqi > 150:
                    return "High Pollution"
                elif aqi > 100:
                    return "Moderate Pollution"
                else:
                    return "Acceptable Levels"
            
            city_summary['pollution_cluster'] = city_summary['aqi'].apply(assign_cluster)
            
            # Cluster visualization
            fig_clusters = px.scatter_mapbox(
                city_summary,
                lat='latitude',
                lon='longitude',
                color='pollution_cluster',
                size='aqi',
                hover_name='city',
                hover_data={'aqi': ':.1f', 'health_risk_score': ':.2f'},
                color_discrete_map={
                    'Acceptable Levels': 'green',
                    'Moderate Pollution': 'yellow',
                    'High Pollution': 'orange',
                    'Severe Pollution': 'red'
                },
                zoom=4.5,
                center={'lat': 20.5937, 'lon': 78.9629},
                mapbox_style=map_style,
                title='Pollution Cluster Analysis'
            )
            
            fig_clusters.update_layout(height=500)
            st.plotly_chart(fig_clusters, use_container_width=True)
            
            # Cluster summary
            cluster_summary = city_summary.groupby('pollution_cluster').agg({
                'city': 'count',
                'aqi': 'mean',
                'health_risk_score': 'mean'
            }).round(2)
            cluster_summary.columns = ['Number of Cities', 'Average AQI', 'Average Health Risk']
            st.dataframe(cluster_summary, use_container_width=True)
        
        with tab4:
            st.subheader("📈 Geographic Trends Over Time")
            
            if days > 1 and 'timestamp' in geo_data.columns:
                # Time series by city
                fig_trends = px.line(
                    geo_data,
                    x='timestamp',
                    y='aqi',
                    color='city',
                    title=f'AQI Trends Over {time_period}',
                    labels={'timestamp': 'Date', 'aqi': 'AQI'}
                )
                st.plotly_chart(fig_trends, use_container_width=True)
                
                # Regional trend analysis
                if 'region' in geo_data.columns:
                    regional_trends = geo_data.groupby(['timestamp', 'region'])['aqi'].mean().reset_index()
                    
                    fig_regional = px.line(
                        regional_trends,
                        x='timestamp',
                        y='aqi',
                        color='region',
                        title='Regional AQI Trends',
                        labels={'timestamp': 'Date', 'aqi': 'Average AQI'}
                    )
                    st.plotly_chart(fig_regional, use_container_width=True)
                
                # Trend statistics
                trend_stats = geo_data.groupby('city').agg({
                    'aqi': ['first', 'last', lambda x: x.last() - x.first()]
                }).round(1)
                trend_stats.columns = ['Initial AQI', 'Final AQI', 'Change']
                trend_stats = trend_stats.reset_index()
                
                st.subheader("📊 AQI Change Over Analysis Period")
                st.dataframe(trend_stats, use_container_width=True)
            
            else:
                st.info("Trend analysis requires historical data. Please select a longer time period.")
    
    elif analysis_type == "Regional Comparison":
        st.subheader("🌏 Regional Air Quality Comparison")
        
        if 'region' in geo_data.columns:
            # Regional summary
            regional_summary = geo_data.groupby('region').agg({
                'aqi': ['mean', 'max', 'min'],
                'pm25': 'mean',
                'pm10': 'mean',
                'health_risk_score': 'mean',
                'city': 'nunique',
                'population': 'sum'
            }).round(2)
            
            regional_summary.columns = ['_'.join(col).strip() for col in regional_summary.columns]
            regional_summary = regional_summary.reset_index()
            
            # Regional comparison charts
            col1, col2 = st.columns(2)
            
            with col1:
                fig_regional_aqi = px.box(
                    geo_data,
                    x='region',
                    y='aqi',
                    title='AQI Distribution by Region',
                    color='region'
                )
                st.plotly_chart(fig_regional_aqi, use_container_width=True)
            
            with col2:
                fig_regional_risk = px.bar(
                    regional_summary,
                    x='region',
                    y='health_risk_score_mean',
                    color='health_risk_score_mean',
                    color_continuous_scale='Reds',
                    title='Average Health Risk by Region'
                )
                st.plotly_chart(fig_regional_risk, use_container_width=True)
            
            # Regional data table
            st.dataframe(regional_summary, use_container_width=True)
        
        else:
            st.error("Regional data not available for comparison.")
    
    elif analysis_type == "Hotspot Analysis":
        st.subheader("🔥 Air Quality Hotspot Analysis")
        
        # Define hotspots based on AQI thresholds
        hotspot_threshold = st.slider("AQI Hotspot Threshold", 100, 300, 150)
        
        hotspots = geo_data[geo_data['aqi'] > hotspot_threshold].copy()
        
        if not hotspots.empty:
            # Hotspot map
            fig_hotspots = px.scatter_mapbox(
                hotspots,
                lat='latitude',
                lon='longitude',
                size='aqi',
                color='health_risk_score',
                hover_name='city',
                hover_data={'aqi': ':.1f', 'pm25': ':.1f'},
                color_continuous_scale='Reds',
                size_max=60,
                zoom=4.5,
                center={'lat': 20.5937, 'lon': 78.9629},
                mapbox_style=map_style,
                title=f'Air Quality Hotspots (AQI > {hotspot_threshold})'
            )
            
            fig_hotspots.update_layout(height=600)
            st.plotly_chart(fig_hotspots, use_container_width=True)
            
            # Hotspot statistics
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Number of Hotspots", len(hotspots))
            
            with col2:
                avg_hotspot_aqi = hotspots['aqi'].mean()
                st.metric("Average Hotspot AQI", f"{avg_hotspot_aqi:.1f}")
            
            with col3:
                total_pop_affected = hotspots['population'].sum()
                st.metric("Population in Hotspots", f"{total_pop_affected:,.0f}")
            
            # Hotspot details
            st.subheader("🔍 Hotspot Details")
            hotspot_details = hotspots.groupby('city').agg({
                'aqi': 'mean',
                'pm25': 'mean',
                'pm10': 'mean',
                'health_risk_score': 'mean',
                'population': 'first'
            }).round(2).reset_index()
            
            st.dataframe(hotspot_details, use_container_width=True)
        
        else:
            st.info(f"No hotspots found with AQI > {hotspot_threshold}")
    
    elif analysis_type == "Spatial Clustering":
        st.subheader("🎯 Spatial Clustering Analysis")
        
        # Implement basic k-means clustering
        from sklearn.cluster import KMeans
        import warnings
        warnings.filterwarnings('ignore')
        
        # Prepare data for clustering
        cluster_data = geo_data.groupby('city').agg({
            'aqi': 'mean',
            'pm25': 'mean',
            'pm10': 'mean',
            'health_risk_score': 'mean',
            'latitude': 'first',
            'longitude': 'first',
            'population': 'first'
        }).reset_index()
        
        if len(cluster_data) >= 3:
            # Select features for clustering
            features = ['aqi', 'pm25', 'pm10', 'health_risk_score']
            available_features = [f for f in features if f in cluster_data.columns]
            
            if available_features:
                # Perform clustering
                n_clusters = min(4, len(cluster_data))
                kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
                cluster_data['cluster'] = kmeans.fit_predict(cluster_data[available_features])
                
                # Cluster visualization
                fig_clusters = px.scatter_mapbox(
                    cluster_data,
                    lat='latitude',
                    lon='longitude',
                    size='population',
                    color='cluster',
                    hover_name='city',
                    hover_data={'aqi': ':.1f', 'health_risk_score': ':.2f'},
                    color_continuous_scale='Viridis',
                    zoom=4.5,
                    center={'lat': 20.5937, 'lon': 78.9629},
                    mapbox_style=map_style,
                    title=f'Spatial Clusters (K-means, k={n_clusters})'
                )
                
                fig_clusters.update_layout(height=600)
                st.plotly_chart(fig_clusters, use_container_width=True)
                
                # Cluster characteristics
                st.subheader("📊 Cluster Characteristics")
                
                cluster_summary = cluster_data.groupby('cluster').agg({
                    'city': 'count',
                    'aqi': 'mean',
                    'health_risk_score': 'mean',
                    'population': 'sum'
                }).round(2)
                
                cluster_summary.columns = ['Cities', 'Avg AQI', 'Avg Health Risk', 'Total Population']
                st.dataframe(cluster_summary, use_container_width=True)
                
                # Cluster interpretation
                for cluster_id in range(n_clusters):
                    cluster_cities = cluster_data[cluster_data['cluster'] == cluster_id]['city'].tolist()
                    avg_aqi = cluster_data[cluster_data['cluster'] == cluster_id]['aqi'].mean()
                    
                    if avg_aqi > 200:
                        st.error(f"🔴 **Cluster {cluster_id}** (Severe): {', '.join(cluster_cities)}")
                    elif avg_aqi > 150:
                        st.warning(f"🟡 **Cluster {cluster_id}** (High): {', '.join(cluster_cities)}")
                    else:
                        st.success(f"🟢 **Cluster {cluster_id}** (Moderate): {', '.join(cluster_cities)}")
            
            else:
                st.error("Insufficient data features for clustering analysis.")
        
        else:
            st.info("Need at least 3 cities for meaningful clustering analysis.")
    
    elif analysis_type == "Distance-Based Analysis":
        st.subheader("📏 Distance-Based Air Quality Analysis")
        
        # Reference city selection
        reference_city = st.selectbox(
            "Select Reference City",
            selected_cities,
            help="Analyze air quality patterns relative to this city"
        )
        
        if reference_city:
            ref_coord = CITY_DATA[reference_city]
            ref_aqi = geo_data[geo_data['city'] == reference_city]['aqi'].mean()
            
            # Calculate distances and differences from reference city
            distance_analysis = []
            
            for city in selected_cities:
                if city != reference_city:
                    city_coord = CITY_DATA[city]
                    city_aqi = geo_data[geo_data['city'] == city]['aqi'].mean()
                    
                    # Calculate distance
                    lat_diff = city_coord['lat'] - ref_coord['lat']
                    lon_diff = city_coord['lon'] - ref_coord['lon']
                    distance = np.sqrt(lat_diff**2 + lon_diff**2) * 111  # Approximate km
                    
                    distance_analysis.append({
                        'City': city,
                        'Distance from Reference (km)': distance,
                        'AQI': city_aqi,
                        'AQI Difference': city_aqi - ref_aqi,
                        'Latitude': city_coord['lat'],
                        'Longitude': city_coord['lon']
                    })
            
            df_distance_analysis = pd.DataFrame(distance_analysis)
            
            if not df_distance_analysis.empty:
                # Distance vs AQI relationship
                fig_distance = px.scatter(
                    df_distance_analysis,
                    x='Distance from Reference (km)',
                    y='AQI Difference',
                    size=abs(df_distance_analysis['AQI Difference']),
                    color='AQI Difference',
                    hover_name='City',
                    color_continuous_scale='RdBu_r',
                    title=f'Air Quality vs Distance from {reference_city}',
                    trendline='ols'
                )
                st.plotly_chart(fig_distance, use_container_width=True)
                
                # Reference city map with distance circles
                fig_ref_map = go.Figure()
                
                # Add reference city
                fig_ref_map.add_trace(go.Scattermapbox(
                    lat=[ref_coord['lat']],
                    lon=[ref_coord['lon']],
                    mode='markers',
                    marker=dict(size=20, color='red'),
                    text=[f"{reference_city} (Reference)"],
                    name='Reference City'
                ))
                
                # Add other cities
                fig_ref_map.add_trace(go.Scattermapbox(
                    lat=df_distance_analysis['Latitude'],
                    lon=df_distance_analysis['Longitude'],
                    mode='markers+text',
                    marker=dict(
                        size=df_distance_analysis['AQI']/10,
                        color=df_distance_analysis['AQI Difference'],
                        colorscale='RdBu_r',
                        showscale=True
                    ),
                    text=df_distance_analysis['City'],
                    textposition='top center',
                    name='Other Cities'
                ))
                
                fig_ref_map.update_layout(
                    mapbox=dict(
                        style=map_style,
                        center=dict(lat=ref_coord['lat'], lon=ref_coord['lon']),
                        zoom=5
                    ),
                    title=f'Air Quality Relative to {reference_city}',
                    height=600
                )
                
                st.plotly_chart(fig_ref_map, use_container_width=True)
                
                # Distance analysis table
                st.subheader("📊 Distance Analysis Results")
                st.dataframe(df_distance_analysis.round(2), use_container_width=True)

# Summary and insights
st.markdown("---")
st.subheader("💡 Geographic Analysis Insights")

if not geo_data.empty:
    # Calculate key insights
    worst_city = geo_data.groupby('city')['aqi'].mean().idxmax()
    best_city = geo_data.groupby('city')['aqi'].mean().idxmin()
    
    worst_aqi = geo_data.groupby('city')['aqi'].mean().max()
    best_aqi = geo_data.groupby('city')['aqi'].mean().min()
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.error(f"🔴 **Worst Air Quality:** {worst_city} (AQI: {worst_aqi:.0f})")
    
    with col2:
        st.success(f"🟢 **Best Air Quality:** {best_city} (AQI: {best_aqi:.0f})")
    
    with col3:
        aqi_range = worst_aqi - best_aqi
        st.info(f"📊 **AQI Range:** {aqi_range:.0f} points")
    
    # Key recommendations
    st.subheader("🎯 Geographic Recommendations")
    
    st.markdown(f"""
    ### Priority Actions by Geographic Analysis:
    
    1. **Immediate Intervention Required:**
       - **{worst_city}**: Implement emergency pollution control measures
       - Deploy air quality monitoring stations in high-risk areas
    
    2. **Best Practices to Replicate:**
       - Study successful interventions in **{best_city}**
       - Implement similar policies in other cities
    
    3. **Regional Coordination:**
       - Establish inter-city pollution monitoring networks
       - Coordinate regional environmental policies
    
    4. **Spatial Hotspot Management:**
       - Target interventions in identified pollution hotspots
       - Implement buffer zones around high-pollution areas
    """)

# Footer
col1, col2, col3 = st.columns(3)

with col1:
    st.info("🗺️ **Analysis**: Comprehensive Geographic Coverage")

with col2:
    st.info("⚡ **Platform**: IBM LinuxONE Spatial Processing")

with col3:
    st.info("🎯 **Insights**: Location-Based Air Quality Intelligence")
